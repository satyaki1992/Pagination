package com.emudhra.emidamUser.service;

import java.util.List;

import com.emudhra.emidamUser.dto.KbaAssignUserQuesDto;
import com.emudhra.emidamUser.dto.KbaSettingsDto;
import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.dto.PasswordSettingsDto;

public interface RegisterAuthenticationService {

	List<KbaViewQuestionDto> getAllQuestionsKba();

	int getCountOfReqQuesToReg();

	List<KbaSettingsDto> getAllSettingsKba();

	boolean registerSecurityQuestion(KbaAssignUserQuesDto kbaQuesAssClassObj, String userId);

	String checkUsernameExist(String username);

	String updatePassword(String newPassword, String username);

	List<PasswordSettingsDto> getAllPasswordSetting();

	String getUserId(String username);

}
