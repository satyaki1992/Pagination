package com.emudhra.emidamUser.dao;

public interface SMSOTPAuthDao {
	void sendMobileOTP(String custID, String mobileNo);

	boolean authenticate(String custID, String verificationCode);

	String findMobileNumber(String id);

	void saveMobileNumber(int userId, String mobNo);
	
	String sendEmailOTP(int userId);
}
