package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserEnrollmentDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 user_enrollment_id;

	@Column
	private int	user_id;

	@Column
	private int	user_auth_val_id;

	@Column
	private String user_auth_type_enrollment_value;

	@Column
	private Date user_enrollment_created_date;

	@Column
	private Date user_enrollment_modified_date;

	@Column
	private int	user_enrollment_created_user;

	@Column
	private int	user_enrollment_modified_user;
	
	@Column
	private String user_enrollment_Status;
	
	@Column
	private String user_enrollment_Flag;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userenrollment_dtls", nullable = false)
	private UserMaster userenrollment_dtls;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userEnrollmentDetailsAuthValMap", nullable = false)
	private AuthenticationValueMapping userEnrollmentDetailsAuthValMap;
	
	
	
	public String getUser_enrollment_Status() {
		return user_enrollment_Status;
	}

	public void setUser_enrollment_Status(String user_enrollment_Status) {
		this.user_enrollment_Status = user_enrollment_Status;
	}

	public String getUser_enrollment_Flag() {
		return user_enrollment_Flag;
	}

	public void setUser_enrollment_Flag(String user_enrollment_Flag) {
		this.user_enrollment_Flag = user_enrollment_Flag;
	}

	public UserMaster getUserenrollment_dtls() {
		return userenrollment_dtls;
	}

	public void setUserenrollment_dtls(UserMaster userenrollment_dtls) {
		this.userenrollment_dtls = userenrollment_dtls;
	}

	public AuthenticationValueMapping getUserEnrollmentDetailsAuthValMap() {
		return userEnrollmentDetailsAuthValMap;
	}

	public void setUserEnrollmentDetailsAuthValMap(AuthenticationValueMapping userEnrollmentDetailsAuthValMap) {
		this.userEnrollmentDetailsAuthValMap = userEnrollmentDetailsAuthValMap;
	}

	public int getUser_enrollment_id() {
		return user_enrollment_id;
	}

	public void setUser_enrollment_id(int user_enrollment_id) {
		this.user_enrollment_id = user_enrollment_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getUser_auth_val_id() {
		return user_auth_val_id;
	}

	public void setUser_auth_val_id(int user_auth_val_id) {
		this.user_auth_val_id = user_auth_val_id;
	}

	public String getUser_auth_type_enrollment_value() {
		return user_auth_type_enrollment_value;
	}

	public void setUser_auth_type_enrollment_value(String user_auth_type_enrollment_value) {
		this.user_auth_type_enrollment_value = user_auth_type_enrollment_value;
	}

	public Date getUser_enrollment_created_date() {
		return user_enrollment_created_date;
	}

	public void setUser_enrollment_created_date(Date user_enrollment_created_date) {
		this.user_enrollment_created_date = user_enrollment_created_date;
	}

	public Date getUser_enrollment_modified_date() {
		return user_enrollment_modified_date;
	}

	public void setUser_enrollment_modified_date(Date user_enrollment_modified_date) {
		this.user_enrollment_modified_date = user_enrollment_modified_date;
	}

	public int getUser_enrollment_created_user() {
		return user_enrollment_created_user;
	}

	public void setUser_enrollment_created_user(int user_enrollment_created_user) {
		this.user_enrollment_created_user = user_enrollment_created_user;
	}

	public int getUser_enrollment_modified_user() {
		return user_enrollment_modified_user;
	}

	public void setUser_enrollment_modified_user(int user_enrollment_modified_user) {
		this.user_enrollment_modified_user = user_enrollment_modified_user;
	}

}
