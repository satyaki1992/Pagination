package com.emudhra.emidamUser.daoImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.emudhra.emidamUser.constants.IdamUserConstants;
import com.emudhra.emidamUser.dao.AuthenticateAuthenticationDao;
import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.entity.AuthenticationValueMapping;
import com.emudhra.emidamUser.entity.UserMaster;
import com.emudhra.emidamUser.formData.LoginForm;
import com.emudhra.emidamUser.service.AuthenticateAuthenticationService;

@Transactional
@Repository
public class AuthenticateAuthenticationDaoImpl implements AuthenticateAuthenticationDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean isUserValid(LoginForm loginForm) {
		
		boolean result = false;
		List<UserMaster> userMasterListObj = null;
		try {
			System.out.println("user name " + loginForm.getUserId() + "  " + loginForm.getPassword());
			userMasterListObj = entityManager.createQuery(
					"From UserMaster um where um.user_Status = :status and um.user_name = :userName and um.active_flag = :flag"
					+ " and um.user_Password =:password")
					.setParameter("status", "LIVE")
					.setParameter("userName", loginForm.getUserId())
					.setParameter("flag", "ACTIVE")
					.setParameter("password", loginForm.getPassword())
					.getResultList();
			if(userMasterListObj.size()>0)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<KbaViewQuestionDto> getKbaQuesForAuth(int pageRowstart, int numRowFromStart, int userId) {
		
		String query="select distinct auth.authentication_value_id, auth.authentication_value from AuthenticationValueMapping auth,"
				+ " UserEnrollmentDetails userEnroll where auth.authentication_value_id=userEnroll.user_auth_val_id and"
				+ " userEnroll.user_id=:user_id and auth.auth_val_status=:auth_val_status and auth.auth_val_flag=:auth_val_flag"
				+ "  and auth.auth_type_id=:auth_type_id";
		List<KbaViewQuestionDto> kbaAuthQues = entityManager.createQuery(query)
				.setParameter("user_id", userId)
				.setParameter("auth_val_status", IdamUserConstants.ISLIVE)
				.setParameter("auth_val_flag", IdamUserConstants.ISACTIVE)
				.setParameter("auth_type_id", Integer.parseInt(IdamUserConstants.KBA))
				.setFirstResult(pageRowstart)
				.setMaxResults(numRowFromStart)
				.getResultList();
		return kbaAuthQues;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getTotalCountQuesShow() {
		
		String query = "FROM AuthenticationValueMapping where auth_val_name=:auth_val_name";
		List<AuthenticationValueMapping> authValmap = entityManager.createQuery(query)
				.setParameter("auth_val_name", "Settings-QuestionToDisplay")
				.getResultList();
		
		String quesToDis = authValmap.get(0).getAuthentication_value();
		return quesToDis;
	}
}
