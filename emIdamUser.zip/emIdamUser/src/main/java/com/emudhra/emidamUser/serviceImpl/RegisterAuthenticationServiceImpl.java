package com.emudhra.emidamUser.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emudhra.emidamUser.constants.IdamUserConstants;
import com.emudhra.emidamUser.dao.RegisterAuthenticationDao;
import com.emudhra.emidamUser.dto.KbaAssignUserQuesDto;
import com.emudhra.emidamUser.dto.KbaSettingsDto;
import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.dto.PasswordSettingsDto;
import com.emudhra.emidamUser.entity.AuthenticationValueMapping;
import com.emudhra.emidamUser.entity.UserEnrollmentDetails;
import com.emudhra.emidamUser.service.RegisterAuthenticationService;
import com.emudhra.emidamUser.util.EncryptAndDecryptUtil;

@Service
public class RegisterAuthenticationServiceImpl implements RegisterAuthenticationService{

	@Autowired
	RegisterAuthenticationDao regAuthDaoClassObj;
	@Autowired
	EncryptAndDecryptUtil encryptAndDecryptUtil;
	
	@Override
	public List<KbaViewQuestionDto> getAllQuestionsKba() {
		
		List<AuthenticationValueMapping> QuesListObj = regAuthDaoClassObj.getAllQuestionsKba();
		List<KbaViewQuestionDto> kbaQuesListObj = new ArrayList<>();
		
		for(AuthenticationValueMapping loop: QuesListObj)
		{
			KbaViewQuestionDto kbaClassObj = new KbaViewQuestionDto(loop.getAuthentication_value_id(), loop.getAuthentication_value());
			kbaQuesListObj.add(kbaClassObj);
		}
		return kbaQuesListObj;
	}
	@Override
	public int getCountOfReqQuesToReg() {
		
		AuthenticationValueMapping authClassObj = regAuthDaoClassObj.getCountOfReqQuesToReg();
		int countOfReqQuesToReg = Integer.parseInt(authClassObj.getAuthentication_value());
		return countOfReqQuesToReg;
	}
	@Override
	public List<KbaSettingsDto> getAllSettingsKba() {
		
		List<AuthenticationValueMapping> kbaSettingsListObj = regAuthDaoClassObj.getAllSettingsKba();
		List<KbaSettingsDto> kbaSetListObj = new ArrayList<>();
		for(AuthenticationValueMapping loop: kbaSettingsListObj)
		{
			KbaSettingsDto kbaSetClassObj = new KbaSettingsDto();
			if(loop.getAuth_val_name().equalsIgnoreCase("Settings-QuestionToRegister"))
				kbaSetClassObj.setQuesRegister(Integer.parseInt(loop.getAuthentication_value()));
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-QuestionToDisplay"))
				kbaSetClassObj.setAuthQuesDisplay(Integer.parseInt(loop.getAuthentication_value()));
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Numeric"))
				kbaSetClassObj.setNumeric(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-SpecialCharacters"))
				kbaSetClassObj.setSpecialCharacters(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-CharLimitAnswer"))
				kbaSetClassObj.setCharLimit(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-MaxCharAns"))
				kbaSetClassObj.setMaxCharsAns(Integer.parseInt(loop.getAuthentication_value()));
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-MinCharAns"))
				kbaSetClassObj.setMinCharsAns(Integer.parseInt(loop.getAuthentication_value()));
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-SameAnsMulQues"))
				kbaSetClassObj.setSameAnsMultiQues(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-NoQuesWordInAnswer"))
				kbaSetClassObj.setNoQuesWordInAns(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-AlgoReqOrNotToStoreAns"))
				kbaSetClassObj.setAlgoToStoreAns(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-AlgoNameForAns"))
				kbaSetClassObj.setAlgoForAns(loop.getAuthentication_value());
			kbaSetListObj.add(kbaSetClassObj);
		}
		return kbaSetListObj;
	}
	@Override
	public boolean registerSecurityQuestion(KbaAssignUserQuesDto kbaQuesAssClassObj, String userId) {
		
		List<UserEnrollmentDetails> userDetListObj = new ArrayList<>();
		UserEnrollmentDetails userEnrollClassObj;
		List<Integer> questions = kbaQuesAssClassObj.getQuesArray();
		List<String> answers = kbaQuesAssClassObj.getAnsArray();
		if(questions == null || answers == null)
		{
			return false;
		}
		for (int i=0; i<questions.size(); i++) 
		{
			userEnrollClassObj = new UserEnrollmentDetails();
			userEnrollClassObj.setUser_id(Integer.parseInt(userId));
			userEnrollClassObj.setUser_auth_val_id(questions.get(i));
			userEnrollClassObj.setUser_auth_type_enrollment_value(answers.get(i));
			userEnrollClassObj.setUser_enrollment_Flag(IdamUserConstants.ISACTIVE);
			userEnrollClassObj.setUser_enrollment_Status(IdamUserConstants.ISLIVE);
			userDetListObj.add(userEnrollClassObj);
		}
		boolean result = regAuthDaoClassObj.registerSecurityQuestion(userDetListObj);
		return result;
	}
	@Override
	public String checkUsernameExist(String username) {
		
		String result = regAuthDaoClassObj.checkUsernameExist(username);
		return result;
	}
	@Override
	public String updatePassword(String newPassword, String username) {
		String encryptedPassword = encryptAndDecryptUtil.createHash(newPassword);
		if(encryptedPassword == null) {
			return "Failed encrypt password";
		}
		String result = regAuthDaoClassObj.updatePassword(encryptedPassword, username);
		return result;
	}
	@Override
	public List<PasswordSettingsDto> getAllPasswordSetting() {
		
		List<AuthenticationValueMapping> passSettingsListObj = regAuthDaoClassObj.getAllSettingsPassword();
		List<PasswordSettingsDto> passSetListObj = new ArrayList<>();
		for(AuthenticationValueMapping loop: passSettingsListObj)
		{
			PasswordSettingsDto passwordSetClassObj = new PasswordSettingsDto();
			if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-passwordLenMin"))
				passwordSetClassObj.setPasswordLenMin(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-passwordLenMax"))
				passwordSetClassObj.setPasswordLenMax(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-numericLenMin"))
				passwordSetClassObj.setNumericLenMin(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-numericLenMax"))
				passwordSetClassObj.setNumericLenMax(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-upperCaseLenMin"))
				passwordSetClassObj.setUpperCaseLenMin(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-upperCaseLenMax"))
				passwordSetClassObj.setUpperCaseLenMax(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-lowerCaseLenMin"))
				passwordSetClassObj.setLowerCaseLenMin(loop.getAuthentication_value());
			else if(loop.getAuth_val_name().equalsIgnoreCase("Settings-Password-lowerCaseLenMax"))
				passwordSetClassObj.setLowerCaseLenMax(loop.getAuthentication_value());
			passSetListObj.add(passwordSetClassObj);
		}
		return passSetListObj;
	}
	@Override
	public String getUserId(String username) {
		
		int userId = regAuthDaoClassObj.getUserId(username);
		return String.valueOf(userId);
	}
}
