package com.emudhra.emidamUser.util;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;
@Component
public class EncryptAndDecryptUtil {
	
	
	private static SecureRandom random = new SecureRandom();
	
	public  String createHash(String signedHash) {

		byte[] bytehasg = signedHash.getBytes();

		MessageDigest md;
		try {
			md = MessageDigest.getInstance("SHA-256");

			ByteArrayInputStream fis12 = new ByteArrayInputStream(bytehasg);
			byte[] dataBytes = new byte[1024];
			int nread = 0;
			while ((nread = fis12.read(dataBytes)) != -1) {
				md.update(dataBytes, 0, nread);
			}
			byte[] hashedData = md.digest();
			String encoded_data = Base64.encodeBase64URLSafeString(hashedData);
			return encoded_data;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	
	public  String generatePassword(int len, String dic) {
		String result = "";
		for (int i = 0; i < len; i++) {
			int index = random.nextInt(dic.length());
			result += dic.charAt(index);
		}
		return result;
	}
}
