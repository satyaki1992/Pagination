package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class OperatorMaster implements Serializable {

	private static final long serialVersionUID = 624039313787487102L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int operator_master_id;

	@Column
	private String operator_type;

	@Column
	private String operator_value;

	@Column
	private Date operator_created_date;

	@Column
	private Date operator_modified_date;

	@Column
	private int	 operated_created_user;

	@Column
	private int	 operator_modified_user;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "operatorMasterTxnParameter")
	private List<TransactionParameter> operatorMasterTxnParameter = new ArrayList<TransactionParameter>();


	public List<TransactionParameter> getOperatorMasterTxnParameter() {
		return operatorMasterTxnParameter;
	}

	public void setOperatorMasterTxnParameter(List<TransactionParameter> operatorMasterTxnParameter) {
		this.operatorMasterTxnParameter = operatorMasterTxnParameter;
	}

	public int getOperator_master_id() {
		return operator_master_id;
	}

	public void setOperator_master_id(int operator_master_id) {
		this.operator_master_id = operator_master_id;
	}

	public String getOperator_type() {
		return operator_type;
	}

	public void setOperator_type(String operator_type) {
		this.operator_type = operator_type;
	}

	public String getOperator_value() {
		return operator_value;
	}

	public void setOperator_value(String operator_value) {
		this.operator_value = operator_value;
	}

	public Date getOperator_created_date() {
		return operator_created_date;
	}

	public void setOperator_created_date(Date operator_created_date) {
		this.operator_created_date = operator_created_date;
	}

	public Date getOperator_modified_date() {
		return operator_modified_date;
	}

	public void setOperator_modified_date(Date operator_modified_date) {
		this.operator_modified_date = operator_modified_date;
	}

	public int getOperated_created_user() {
		return operated_created_user;
	}

	public void setOperated_created_user(int operated_created_user) {
		this.operated_created_user = operated_created_user;
	}

	public int getOperator_modified_user() {
		return operator_modified_user;
	}

	public void setOperator_modified_user(int operator_modified_user) {
		this.operator_modified_user = operator_modified_user;
	}



}
