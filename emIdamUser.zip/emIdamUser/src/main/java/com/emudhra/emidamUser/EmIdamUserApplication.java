package com.emudhra.emidamUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.emudhra.emidamUser.*")
public class EmIdamUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmIdamUserApplication.class, args);
	}
}
