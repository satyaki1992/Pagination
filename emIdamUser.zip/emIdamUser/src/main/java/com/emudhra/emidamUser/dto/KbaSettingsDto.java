package com.emudhra.emidamUser.dto;

public class KbaSettingsDto {
	
	private int quesRegister;
	private int authQuesDisplay;
	private String numeric;
	private String specialCharacters;
	private String charLimit;
	private int maxCharsAns;
	private int minCharsAns;
	private String sameAnsMultiQues;
	private String noQuesWordInAns;
	private String algoToStoreAns;
	private String algoForAns;
	public int getQuesRegister() {
		return quesRegister;
	}
	public void setQuesRegister(int quesRegister) {
		this.quesRegister = quesRegister;
	}
	public int getAuthQuesDisplay() {
		return authQuesDisplay;
	}
	public void setAuthQuesDisplay(int authQuesDisplay) {
		this.authQuesDisplay = authQuesDisplay;
	}
	public String getNumeric() {
		return numeric;
	}
	public void setNumeric(String numeric) {
		this.numeric = numeric;
	}
	public String getSpecialCharacters() {
		return specialCharacters;
	}
	public void setSpecialCharacters(String specialCharacters) {
		this.specialCharacters = specialCharacters;
	}
	public String getCharLimit() {
		return charLimit;
	}
	public void setCharLimit(String charLimit) {
		this.charLimit = charLimit;
	}
	public int getMaxCharsAns() {
		return maxCharsAns;
	}
	public void setMaxCharsAns(int maxCharsAns) {
		this.maxCharsAns = maxCharsAns;
	}
	public int getMinCharsAns() {
		return minCharsAns;
	}
	public void setMinCharsAns(int minCharsAns) {
		this.minCharsAns = minCharsAns;
	}
	
	public String getNoQuesWordInAns() {
		return noQuesWordInAns;
	}
	public void setNoQuesWordInAns(String noQuesWordInAns) {
		this.noQuesWordInAns = noQuesWordInAns;
	}
	
	public String getSameAnsMultiQues() {
		return sameAnsMultiQues;
	}
	public void setSameAnsMultiQues(String sameAnsMultiQues) {
		this.sameAnsMultiQues = sameAnsMultiQues;
	}
	public String getAlgoToStoreAns() {
		return algoToStoreAns;
	}
	public void setAlgoToStoreAns(String algoToStoreAns) {
		this.algoToStoreAns = algoToStoreAns;
	}
	public String getAlgoForAns() {
		return algoForAns;
	}
	public void setAlgoForAns(String algoForAns) {
		this.algoForAns = algoForAns;
	}
	
	
}
