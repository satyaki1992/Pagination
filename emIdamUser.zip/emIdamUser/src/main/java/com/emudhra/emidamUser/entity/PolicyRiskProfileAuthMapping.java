package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PolicyRiskProfileAuthMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int policy_auth_mapping_id;

	@Column
	private String risk_value;

	@Column
	private int auth_type_id;

	@Column
	private int auth_order;

	@Column
	private Date policy_auth_mapping_created_date;

	@Column
	private Date policy_auth_mapping_modified_date;

	@Column
	private int policy_auth_mapping_created_user;

	@Column
	private int policy_auth_mapping_modified_user;

	@Column
	private String first_factor_auth;

	@Column
	private String second_factor_auth;

	@Column
	private String third_factor_auth;

	@Column
	private String is_active = "Active";

	@Column
	private String is_deleted = "LIVE";

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "policyRiskProfileAuthMapping")
	private AuthenticationTypeMaster policyRiskProfileAuthMapping;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "riskMasterPolicyRiskProfileAuthMapping")
	private RiskMaster riskMasterPolicyRiskProfileAuthMapping;

	public RiskMaster getRiskMasterPolicyRiskProfileAuthMapping() {
		return riskMasterPolicyRiskProfileAuthMapping;
	}

	public void setRiskMasterPolicyRiskProfileAuthMapping(RiskMaster riskMasterPolicyRiskProfileAuthMapping) {
		this.riskMasterPolicyRiskProfileAuthMapping = riskMasterPolicyRiskProfileAuthMapping;
	}

	public AuthenticationTypeMaster getPolicyRiskProfileAuthMapping() {
		return policyRiskProfileAuthMapping;
	}

	public void setPolicyRiskProfileAuthMapping(AuthenticationTypeMaster policyRiskProfileAuthMapping) {
		this.policyRiskProfileAuthMapping = policyRiskProfileAuthMapping;
	}

	public int getPolicy_auth_mapping_id() {
		return policy_auth_mapping_id;
	}

	public void setPolicy_auth_mapping_id(int policy_auth_mapping_id) {
		this.policy_auth_mapping_id = policy_auth_mapping_id;
	}

	public String getRisk_value() {
		return risk_value;
	}

	public void setRisk_value(String risk_value) {
		this.risk_value = risk_value;
	}

	public int getAuth_type_id() {
		return auth_type_id;
	}

	public void setAuth_type_id(int auth_type_id) {
		this.auth_type_id = auth_type_id;
	}

	public int getAuth_order() {
		return auth_order;
	}

	public void setAuth_order(int auth_order) {
		this.auth_order = auth_order;
	}

	public Date getPolicy_auth_mapping_created_date() {
		return policy_auth_mapping_created_date;
	}

	public void setPolicy_auth_mapping_created_date(Date policy_auth_mapping_created_date) {
		this.policy_auth_mapping_created_date = policy_auth_mapping_created_date;
	}

	public Date getPolicy_auth_mapping_modified_date() {
		return policy_auth_mapping_modified_date;
	}

	public void setPolicy_auth_mapping_modified_date(Date policy_auth_mapping_modified_date) {
		this.policy_auth_mapping_modified_date = policy_auth_mapping_modified_date;
	}

	public int getPolicy_auth_mapping_created_user() {
		return policy_auth_mapping_created_user;
	}

	public void setPolicy_auth_mapping_created_user(int policy_auth_mapping_created_user) {
		this.policy_auth_mapping_created_user = policy_auth_mapping_created_user;
	}

	public int getPolicy_auth_mapping_modified_user() {
		return policy_auth_mapping_modified_user;
	}

	public void setPolicy_auth_mapping_modified_user(int policy_auth_mapping_modified_user) {
		this.policy_auth_mapping_modified_user = policy_auth_mapping_modified_user;
	}

	public String getFirst_factor_auth() {
		return first_factor_auth;
	}

	public void setFirst_factor_auth(String first_factor_auth) {
		this.first_factor_auth = first_factor_auth;
	}

	public String getSecond_factor_auth() {
		return second_factor_auth;
	}

	public void setSecond_factor_auth(String second_factor_auth) {
		this.second_factor_auth = second_factor_auth;
	}

	public String getThird_factor_auth() {
		return third_factor_auth;
	}

	public void setThird_factor_auth(String third_factor_auth) {
		this.third_factor_auth = third_factor_auth;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(String is_deleted) {
		this.is_deleted = is_deleted;
	}

}
