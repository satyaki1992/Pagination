package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

//@NamedQueries(value = { 
//		@NamedQuery(name = "com.emudhra.idam.daoImpl.AppsMgrImpl.getAppApprover", 
//				    query = "from com.emudhra.idam.entity.AppMaster appMaster where appMaster.app_name = :app_name")
//   })

@Entity
public class RiskMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int risk_id;

	@Column(unique=true)
	private String risk_name;

	@Column(unique=true)
	private String risk_value;

	@Column
	private Date risk_created_date;

	@Column
	private Date risk_modified_date;

	@Column
	private int risk_created_user;

	@Column
	private int risk_modified_user;

	@Column
	private String is_active = "Active";

	@Column
	private String is_deleted = "LIVE";

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(String is_deleted) {
		this.is_deleted = is_deleted;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "riskMasterRiskProfiles")
	private List<RiskProfiles> riskMasterRiskProfiles = new ArrayList<RiskProfiles>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "riskMasterPolicyRiskProfileAuthMapping")
	private List<PolicyRiskProfileAuthMapping> riskMasterPolicyRiskProfileAuthMapping = new ArrayList<PolicyRiskProfileAuthMapping>();

	public int getRisk_id() {
		return risk_id;
	}

	public void setRisk_id(int risk_id) {
		this.risk_id = risk_id;
	}

	public String getRisk_name() {
		return risk_name;
	}

	public void setRisk_name(String risk_name) {
		this.risk_name = risk_name;
	}

	public String getRisk_value() {
		return risk_value;
	}

	public void setRisk_value(String risk_value) {
		this.risk_value = risk_value;
	}

	public Date getRisk_created_date() {
		return risk_created_date;
	}

	public void setRisk_created_date(Date risk_created_date) {
		this.risk_created_date = risk_created_date;
	}

	public Date getRisk_modified_date() {
		return risk_modified_date;
	}

	public void setRisk_modified_date(Date risk_modified_date) {
		this.risk_modified_date = risk_modified_date;
	}

	public int getRisk_created_user() {
		return risk_created_user;
	}

	public void setRisk_created_user(int risk_created_user) {
		this.risk_created_user = risk_created_user;
	}

	public int getRisk_modified_user() {
		return risk_modified_user;
	}

	public void setRisk_modified_user(int risk_modified_user) {
		this.risk_modified_user = risk_modified_user;
	}

	public List<RiskProfiles> getRiskMasterRiskProfiles() {
		return riskMasterRiskProfiles;
	}

	public void setRiskMasterRiskProfiles(List<RiskProfiles> riskMasterRiskProfiles) {
		this.riskMasterRiskProfiles = riskMasterRiskProfiles;
	}

	public List<PolicyRiskProfileAuthMapping> getRiskMasterPolicyRiskProfileAuthMapping() {
		return riskMasterPolicyRiskProfileAuthMapping;
	}

	public void setRiskMasterPolicyRiskProfileAuthMapping(
			List<PolicyRiskProfileAuthMapping> riskMasterPolicyRiskProfileAuthMapping) {
		this.riskMasterPolicyRiskProfileAuthMapping = riskMasterPolicyRiskProfileAuthMapping;
	}

}
