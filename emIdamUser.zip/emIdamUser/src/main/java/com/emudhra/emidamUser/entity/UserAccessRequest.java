package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserAccessRequest implements Serializable {
	
	private static final long serialVersionUID = 624039313787487102L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int user_access_request_id;

	@Column
	private int user_id;
	
	@Column
	private int app_id;
	
	@Column
	private int resource_id;

	@Column
	private Date user_access_request_date;
	
	@Column
	private Date user_access_approval_date;

	@Column
	private String approval_flag;

	@Column
	private int user_access_created_user;

	@Column
	private int user_access_approved_user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userAccessRequest", nullable = false)
	private UserMaster userAccessRequest;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "usrAccReqAppMasterId", nullable = false)
	private AppMaster usrAccReqAppMasterId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "resourceMappingUserAccessRequest", nullable = false)
	private ResourceMapping resourceMappingUserAccessRequest;
	
	public ResourceMapping getResourceMappingUserAccessRequest() {
		return resourceMappingUserAccessRequest;
	}

	public void setResourceMappingUserAccessRequest(ResourceMapping resourceMappingUserAccessRequest) {
		this.resourceMappingUserAccessRequest = resourceMappingUserAccessRequest;
	}

	public AppMaster getUsrAccReqAppMasterId() {
		return usrAccReqAppMasterId;
	}

	public void setUsrAccReqAppMasterId(AppMaster usrAccReqAppMasterId) {
		this.usrAccReqAppMasterId = usrAccReqAppMasterId;
	}

	public UserMaster getUserAccessRequest() {
		return userAccessRequest;
	}

	public void setUserAccessRequest(UserMaster userAccessRequest) {
		this.userAccessRequest = userAccessRequest;
	}

	public int getUser_access_request_id() {
		return user_access_request_id;
	}

	public void setUser_access_request_id(int user_access_request_id) {
		this.user_access_request_id = user_access_request_id;
	}

	public Date getUser_access_request_date() {
		return user_access_request_date;
	}

	public void setUser_access_request_date(Date user_access_request_date) {
		this.user_access_request_date = user_access_request_date;
	}

	public Date getUser_access_approval_date() {
		return user_access_approval_date;
	}

	public void setUser_access_approval_date(Date user_access_approval_date) {
		this.user_access_approval_date = user_access_approval_date;
	}

	public String getApproval_flag() {
		return approval_flag;
	}

	public void setApproval_flag(String approval_flag) {
		this.approval_flag = approval_flag;
	}

	public int getUser_access_created_user() {
		return user_access_created_user;
	}

	public void setUser_access_created_user(int user_access_created_user) {
		this.user_access_created_user = user_access_created_user;
	}

	public int getUser_access_approved_user() {
		return user_access_approved_user;
	}

	public void setUser_access_approved_user(int user_access_approved_user) {
		this.user_access_approved_user = user_access_approved_user;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public int getResource_id() {
		return resource_id;
	}

	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}

}
