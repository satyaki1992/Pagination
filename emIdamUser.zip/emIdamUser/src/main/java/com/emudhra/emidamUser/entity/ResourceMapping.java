package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ResourceMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int resource_id;

	@Column
	private int app_id;

	@Column
	private String resource_type;

	@Column
	private String resource_value;

	@Column
	private Date resource_mapping_created_date;

	@Column
	private Date resource_mapping_modified_date;

	@Column
	private String resource_mapping_created_user;

	@Column
	private String resource_mapping_modified_user;

	@Column
	private String isActive = "Active";

	@Column
	private String isDelete = "LIVE";

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "resourceMappingAuditTrail")
	private List<AuditTrail> resourceMappingAuditTrail = new ArrayList<AuditTrail>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "resourceMappingRiskProfiles")
	private List<RiskProfiles> resourceMappingRiskProfiles = new ArrayList<RiskProfiles>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "resourceMappingUserAccessRequest")
	private List<UserAccessRequest> resourceMappingUserAccessRequest = new ArrayList<UserAccessRequest>();

	// @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy =
	// "resourceMappingRedirectURL")
	// private List<RedirectURL> resourceMappingRedirectURL = new
	// ArrayList<RedirectURL>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "redirectURL")
	private RedirectURL redirectURL;

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}

	public List<UserAccessRequest> getResourceMappingUserAccessRequest() {
		return resourceMappingUserAccessRequest;
	}

	public void setResourceMappingUserAccessRequest(List<UserAccessRequest> resourceMappingUserAccessRequest) {
		this.resourceMappingUserAccessRequest = resourceMappingUserAccessRequest;
	}

	public List<RiskProfiles> getResourceMappingRiskProfiles() {
		return resourceMappingRiskProfiles;
	}

	public void setResourceMappingRiskProfiles(List<RiskProfiles> resourceMappingRiskProfiles) {
		this.resourceMappingRiskProfiles = resourceMappingRiskProfiles;
	}

	public List<AuditTrail> getResourceMappingAuditTrail() {
		return resourceMappingAuditTrail;
	}

	public void setResourceMappingAuditTrail(List<AuditTrail> resourceMappingAuditTrail) {
		this.resourceMappingAuditTrail = resourceMappingAuditTrail;
	}

	public int getResource_id() {
		return resource_id;
	}

	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public String getResource_type() {
		return resource_type;
	}

	public void setResource_type(String resource_type) {
		this.resource_type = resource_type;
	}

	public String getResource_value() {
		return resource_value;
	}

	public void setResource_value(String resource_value) {
		this.resource_value = resource_value;
	}

	public Date getResource_mapping_created_date() {
		return resource_mapping_created_date;
	}

	public void setResource_mapping_created_date(Date resource_mapping_created_date) {
		this.resource_mapping_created_date = resource_mapping_created_date;
	}

	public Date getResource_mapping_modified_date() {
		return resource_mapping_modified_date;
	}

	public void setResource_mapping_modified_date(Date resource_mapping_modified_date) {
		this.resource_mapping_modified_date = resource_mapping_modified_date;
	}

	public String getResource_mapping_created_user() {
		return resource_mapping_created_user;
	}

	public void setResource_mapping_created_user(String resource_mapping_created_user) {
		this.resource_mapping_created_user = resource_mapping_created_user;
	}

	public String getResource_mapping_modified_user() {
		return resource_mapping_modified_user;
	}

	public void setResource_mapping_modified_user(String resource_mapping_modified_user) {
		this.resource_mapping_modified_user = resource_mapping_modified_user;
	}

	public RedirectURL getRedirectURL() {
		return redirectURL;
	}

	public void setRedirectURL(RedirectURL redirectURL) {
		this.redirectURL = redirectURL;
	}
}
