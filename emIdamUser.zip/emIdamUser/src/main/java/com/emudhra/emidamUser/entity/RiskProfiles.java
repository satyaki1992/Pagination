package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class RiskProfiles implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int risk_profile_id;

	@Column
	private int user_id;

	@Column
	private int group_id;

	@Column
	private int app_id;

	@Column
	private int resource_id;

	@Column
	private int txn_parameter_id;

	@Column
	private String txn_parameter_operator;

	@Column
	private String txn_parameter_start_value = "0";

	@Column
	private String txn_parameter_end_value;

	@Column
	private String risk_value;

	@Column
	private String ip_change;

	@Column
	private Date risk_profile_created_dt;

	@Column
	private Date risk_profile_modified_dt;

	@Column
	private int risk_profiles_created_user;

	@Column
	private int risk_profiles_modified_user;

	@Column
	private String is_active = "Active";

	@Column
	private String is_deleted = "LIVE";

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "riskprofiles")
	private UserMaster riskprofiles;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appMasterRiskProfiles")
	private AppMaster appMasterRiskProfiles;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "resourceMappingRiskProfiles")
	private ResourceMapping resourceMappingRiskProfiles;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "txnParameterRiskProfiles")
	private TransactionParameter txnParameterRiskProfiles;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userGroupsRiskProfiles")
	private UserGroups userGroupsRiskProfiles;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "riskMasterRiskProfiles")
	private RiskMaster riskMasterRiskProfiles;

	public RiskMaster getRiskMasterRiskProfiles() {
		return riskMasterRiskProfiles;
	}

	public void setRiskMasterRiskProfiles(RiskMaster riskMasterRiskProfiles) {
		this.riskMasterRiskProfiles = riskMasterRiskProfiles;
	}

	public TransactionParameter getTxnParameterRiskProfiles() {
		return txnParameterRiskProfiles;
	}

	public void setTxnParameterRiskProfiles(TransactionParameter txnParameterRiskProfiles) {
		this.txnParameterRiskProfiles = txnParameterRiskProfiles;
	}

	public UserGroups getUserGroupsRiskProfiles() {
		return userGroupsRiskProfiles;
	}

	public void setUserGroupsRiskProfiles(UserGroups userGroupsRiskProfiles) {
		this.userGroupsRiskProfiles = userGroupsRiskProfiles;
	}

	public ResourceMapping getResourceMappingRiskProfiles() {
		return resourceMappingRiskProfiles;
	}

	public void setResourceMappingRiskProfiles(ResourceMapping resourceMappingRiskProfiles) {
		this.resourceMappingRiskProfiles = resourceMappingRiskProfiles;
	}

	public AppMaster getAppMasterRiskProfiles() {
		return appMasterRiskProfiles;
	}

	public void setAppMasterRiskProfiles(AppMaster appMasterRiskProfiles) {
		this.appMasterRiskProfiles = appMasterRiskProfiles;
	}

	public int getRisk_profile_id() {
		return risk_profile_id;
	}

	public void setRisk_profile_id(int risk_profile_id) {
		this.risk_profile_id = risk_profile_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getGroup_id() {
		return group_id;
	}

	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public int getResource_id() {
		return resource_id;
	}

	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}

	public int getTxn_parameter_id() {
		return txn_parameter_id;
	}

	public void setTxn_parameter_id(int txn_parameter_id) {
		this.txn_parameter_id = txn_parameter_id;
	}

	public String getTxn_parameter_operator() {
		return txn_parameter_operator;
	}

	public void setTxn_parameter_operator(String txn_parameter_operator) {
		this.txn_parameter_operator = txn_parameter_operator;
	}

	public String getTxn_parameter_start_value() {
		return txn_parameter_start_value;
	}

	public void setTxn_parameter_start_value(String txn_parameter_start_value) {
		this.txn_parameter_start_value = txn_parameter_start_value;
	}

	public String getTxn_parameter_end_value() {
		return txn_parameter_end_value;
	}

	public void setTxn_parameter_end_value(String txn_parameter_end_value) {
		this.txn_parameter_end_value = txn_parameter_end_value;
	}

	public String getRisk_value() {
		return risk_value;
	}

	public void setRisk_value(String risk_value) {
		this.risk_value = risk_value;
	}

	public String getIp_change() {
		return ip_change;
	}

	public void setIp_change(String ip_change) {
		this.ip_change = ip_change;
	}

	public Date getRisk_profile_created_dt() {
		return risk_profile_created_dt;
	}

	public void setRisk_profile_created_dt(Date risk_profile_created_dt) {
		this.risk_profile_created_dt = risk_profile_created_dt;
	}

	public Date getRisk_profile_modified_dt() {
		return risk_profile_modified_dt;
	}

	public void setRisk_profile_modified_dt(Date risk_profile_modified_dt) {
		this.risk_profile_modified_dt = risk_profile_modified_dt;
	}

	public int getRisk_profiles_created_user() {
		return risk_profiles_created_user;
	}

	public void setRisk_profiles_created_user(int risk_profiles_created_user) {
		this.risk_profiles_created_user = risk_profiles_created_user;
	}

	public int getRisk_profiles_modified_user() {
		return risk_profiles_modified_user;
	}

	public void setRisk_profiles_modified_user(int risk_profiles_modified_user) {
		this.risk_profiles_modified_user = risk_profiles_modified_user;
	}

	public UserMaster getRiskprofiles() {
		return riskprofiles;
	}

	public void setRiskprofiles(UserMaster riskprofiles) {
		this.riskprofiles = riskprofiles;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(String is_deleted) {
		this.is_deleted = is_deleted;
	}

}
