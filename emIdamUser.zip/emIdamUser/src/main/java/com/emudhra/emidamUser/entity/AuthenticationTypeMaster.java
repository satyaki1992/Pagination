package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class AuthenticationTypeMaster implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 auth_type_id;
	
	@Column
	private String auth_type_name;
	
	@Column
	private String auth_strength_value;
	
	@Column
	private String auth_type_created_user;
	
	@Column
	private String auth_type_modified_user;
		
	@Column
	private Date auth_type_created_date;
	
	@Column
	private Date auth_type_modified_date;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "policyRiskProfileAuthMapping")
	private List<PolicyRiskProfileAuthMapping> policyRiskProfileAuthMapping = new ArrayList<PolicyRiskProfileAuthMapping>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "authenticationValueMapping")
	private List<AuthenticationValueMapping> authenticationValueMapping = new ArrayList<AuthenticationValueMapping>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "authTypeMasterAuditTrail")
	private List<AuditTrail> authTypeMasterAuditTrail = new ArrayList<AuditTrail>();

	public List<AuditTrail> getAuthTypeMasterAuditTrail() {
		return authTypeMasterAuditTrail;
	}

	public void setAuthTypeMasterAuditTrail(List<AuditTrail> authTypeMasterAuditTrail) {
		this.authTypeMasterAuditTrail = authTypeMasterAuditTrail;
	}

	public List<AuthenticationValueMapping> getAuthenticationValueMapping() {
		return authenticationValueMapping;
	}

	public void setAuthenticationValueMapping(List<AuthenticationValueMapping> authenticationValueMapping) {
		this.authenticationValueMapping = authenticationValueMapping;
	}

	public List<PolicyRiskProfileAuthMapping> getPolicyRiskProfileAuthMapping() {
		return policyRiskProfileAuthMapping;
	}

	public void setPolicyRiskProfileAuthMapping(List<PolicyRiskProfileAuthMapping> policyRiskProfileAuthMapping) {
		this.policyRiskProfileAuthMapping = policyRiskProfileAuthMapping;
	}

	public int getAuth_type_id() {
		return auth_type_id;
	}

	public void setAuth_type_id(int auth_type_id) {
		this.auth_type_id = auth_type_id;
	}

	public String getAuth_type_name() {
		return auth_type_name;
	}

	public void setAuth_type_name(String auth_type_name) {
		this.auth_type_name = auth_type_name;
	}

	public String getAuth_strength_value() {
		return auth_strength_value;
	}

	public void setAuth_strength_value(String auth_strength_value) {
		this.auth_strength_value = auth_strength_value;
	}

	public String getAuth_type_created_user() {
		return auth_type_created_user;
	}

	public void setAuth_type_created_user(String auth_type_created_user) {
		this.auth_type_created_user = auth_type_created_user;
	}

	public String getAuth_type_modified_user() {
		return auth_type_modified_user;
	}

	public void setAuth_type_modified_user(String auth_type_modified_user) {
		this.auth_type_modified_user = auth_type_modified_user;
	}

	public Date getAuth_type_created_date() {
		return auth_type_created_date;
	}

	public void setAuth_type_created_date(Date auth_type_created_date) {
		this.auth_type_created_date = auth_type_created_date;
	}

	public Date getAuth_type_modified_date() {
		return auth_type_modified_date;
	}

	public void setAuth_type_modified_date(Date auth_type_modified_date) {
		this.auth_type_modified_date = auth_type_modified_date;
	}
	
	
		
}
