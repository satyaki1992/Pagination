package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class UserGroups implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 user_group_id;
	
	@Column(unique=true,nullable=false)
	private String	user_group_name;
	
	@Column
	private Date user_group_created_date;
	
	@Column
	private Date user_group_modified_date;
	
	@Column
	private String	user_group_created_user;
	
	@Column
	private String	user_group_modified_user;
	
	@Column
	private String user_group_Status = "LIVE";
	
	@Column
	private String user_group_Flag = "Active";
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userGroupsRiskProfiles")
	private List<RiskProfiles> userGroupsRiskProfiles = new ArrayList<RiskProfiles>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userGroupsUserGroupMapping")
	private List<UserGroupMapping> userGroupsUserGroupMapping = new ArrayList<UserGroupMapping>();


	public String getUser_group_Status() {
		return user_group_Status;
	}

	public void setUser_group_Status(String user_group_Status) {
		this.user_group_Status = user_group_Status;
	}

	public String getUser_group_Flag() {
		return user_group_Flag;
	}

	public void setUser_group_Flag(String user_group_Flag) {
		this.user_group_Flag = user_group_Flag;
	}

	public List<UserGroupMapping> getUserGroupsUserGroupMapping() {
		return userGroupsUserGroupMapping;
	}

	public void setUserGroupsUserGroupMapping(List<UserGroupMapping> userGroupsUserGroupMapping) {
		this.userGroupsUserGroupMapping = userGroupsUserGroupMapping;
	}

	public List<RiskProfiles> getUserGroupsRiskProfiles() {
		return userGroupsRiskProfiles;
	}

	public void setUserGroupsRiskProfiles(List<RiskProfiles> userGroupsRiskProfiles) {
		this.userGroupsRiskProfiles = userGroupsRiskProfiles;
	}

	public int getUser_group_id() {
		return user_group_id;
	}

	public void setUser_group_id(int user_group_id) {
		this.user_group_id = user_group_id;
	}

	public String getUser_group_name() {
		return user_group_name;
	}

	public void setUser_group_name(String user_group_name) {
		this.user_group_name = user_group_name;
	}

	public Date getUser_group_created_date() {
		return user_group_created_date;
	}

	public void setUser_group_created_date(Date user_group_created_date) {
		this.user_group_created_date = user_group_created_date;
	}

	public Date getUser_group_modified_date() {
		return user_group_modified_date;
	}

	public void setUser_group_modified_date(Date user_group_modified_date) {
		this.user_group_modified_date = user_group_modified_date;
	}

	public String getUser_group_created_user() {
		return user_group_created_user;
	}

	public void setUser_group_created_user(String user_group_created_user) {
		this.user_group_created_user = user_group_created_user;
	}

	public String getUser_group_modified_user() {
		return user_group_modified_user;
	}

	public void setUser_group_modified_user(String user_group_modified_user) {
		this.user_group_modified_user = user_group_modified_user;
	}

}
