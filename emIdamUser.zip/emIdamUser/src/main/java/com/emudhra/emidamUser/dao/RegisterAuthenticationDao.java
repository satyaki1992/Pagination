package com.emudhra.emidamUser.dao;

import java.util.List;

import com.emudhra.emidamUser.entity.AuthenticationValueMapping;
import com.emudhra.emidamUser.entity.UserEnrollmentDetails;

public interface RegisterAuthenticationDao {

	boolean registerSecurityQuestion(List<UserEnrollmentDetails> userDetListObj);
	List<AuthenticationValueMapping> getAllQuestionsKba();
	AuthenticationValueMapping getCountOfReqQuesToReg();
	List<AuthenticationValueMapping> getAllSettingsKba();
	String checkUsernameExist(String username);
	String updatePassword(String newPassword, String username);
	List<AuthenticationValueMapping> getAllSettingsPassword();
	int getUserId(String username);
}
