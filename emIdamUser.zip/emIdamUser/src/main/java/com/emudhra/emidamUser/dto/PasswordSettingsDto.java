package com.emudhra.emidamUser.dto;

public class PasswordSettingsDto {
	
	private String passwordLenMin;
	private String passwordLenMax;
	private String numericLenMin;
	private String numericLenMax;
	private String upperCaseLenMin;
	private String upperCaseLenMax;
	private String lowerCaseLenMin;
	private String lowerCaseLenMax;
	public String getPasswordLenMin() {
		return passwordLenMin;
	}
	public void setPasswordLenMin(String passwordLenMin) {
		this.passwordLenMin = passwordLenMin;
	}
	public String getPasswordLenMax() {
		return passwordLenMax;
	}
	public void setPasswordLenMax(String passwordLenMax) {
		this.passwordLenMax = passwordLenMax;
	}
	public String getNumericLenMin() {
		return numericLenMin;
	}
	public void setNumericLenMin(String numericLenMin) {
		this.numericLenMin = numericLenMin;
	}
	public String getNumericLenMax() {
		return numericLenMax;
	}
	public void setNumericLenMax(String numericLenMax) {
		this.numericLenMax = numericLenMax;
	}
	public String getUpperCaseLenMin() {
		return upperCaseLenMin;
	}
	public void setUpperCaseLenMin(String upperCaseLenMin) {
		this.upperCaseLenMin = upperCaseLenMin;
	}
	public String getUpperCaseLenMax() {
		return upperCaseLenMax;
	}
	public void setUpperCaseLenMax(String upperCaseLenMax) {
		this.upperCaseLenMax = upperCaseLenMax;
	}
	public String getLowerCaseLenMin() {
		return lowerCaseLenMin;
	}
	public void setLowerCaseLenMin(String lowerCaseLenMin) {
		this.lowerCaseLenMin = lowerCaseLenMin;
	}
	public String getLowerCaseLenMax() {
		return lowerCaseLenMax;
	}
	public void setLowerCaseLenMax(String lowerCaseLenMax) {
		this.lowerCaseLenMax = lowerCaseLenMax;
	}
}
