package com.emudhra.emidamUser.constants;

public class IdamUserConstants {

	/*	Authentication Types	*/
	public static final String KBA="4";
	public static final String SMSOTP="2";
	public static final String EmailOtp="3";
	public static final String FIDO="10";
	public static final String DSC="9";
	public static final String PASSWORD="1";
	public static final String GRID="8";
	
	/*	Different status of Users	*/
	public static final String ISLIVE = "LIVE";
	public static final String ISDELETED = "DELETED";
	public static final String ISACTIVE = "ACTIVE";
	public static final String ISINACTIVE = "INACTIVE";
	
	public static final String MOBNO_REG="Mobile Number Registered.";
	public static final String MOBNO_NOT_REG="Mobile Number Not Registered.";
}
