package com.emudhra.emidamUser.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.formData.LoginForm;
import com.emudhra.emidamUser.service.AuthenticateAuthenticationService;

@Controller
public class AuthenticateUserAuthenticationController {
	
	@Autowired
	AuthenticateAuthenticationService authServiceClassObj; 
	
	@RequestMapping(value = "/password.html", method = RequestMethod.GET)
	public String passwordPageDisplay() {
		return "password";
	}
	@RequestMapping(value = "/password.html", method = RequestMethod.POST)
	public String passwordVerify(String password, Model model, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("usernameInUse");
		LoginForm loginForm = new LoginForm();
		loginForm.setUserId(username);
		loginForm.setPassword(password);
			
		if(username == null)
			return "redirect:/username.html";
		boolean result = authServiceClassObj.isUserValid(loginForm);
		if(result == true)
		{
			session.setAttribute("username", username);
			return "redirect:/register-security-Question.html";
		}
		else
		{
			model.addAttribute("status", "Wrong Password");
			return "password";
		}
	}
	
	@RequestMapping(value = "/authenticate-security-Question.html", method = RequestMethod.GET)
	public String getregisterSecurityQuestionPage(@RequestParam(value = "ques", required = false) String question, Model model,
			HttpServletRequest request) {
		
		int currQues = 0;
		if(question != null)
			currQues = Integer.parseInt(question);
		else
			currQues=1;
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");
		
		List<KbaViewQuestionDto> quesKbaAuthListObj = authServiceClassObj.getKbaQuesForAuth(((currQues-1)*1),1,username); 
		model.addAttribute("quesKbaAuthListObj", quesKbaAuthListObj);
		return "authenticate-security-Question";
	}
	@RequestMapping(value = "/authenticate-security-Question.html", method = RequestMethod.POST)
	@ResponseBody
	public String getTotalCountQuesShow() {
		String totalCountRows = authServiceClassObj.getTotalCountQuesShow();
		
		return totalCountRows;
	}
}
