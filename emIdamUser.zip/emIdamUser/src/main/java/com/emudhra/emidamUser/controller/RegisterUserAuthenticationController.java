package com.emudhra.emidamUser.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.emudhra.emidamUser.dto.KbaSettingsDto;
import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.dto.PasswordSettingsDto;
import com.emudhra.emidamUser.service.RegisterAuthenticationService;

@Controller
public class RegisterUserAuthenticationController {
	
	@Autowired
	RegisterAuthenticationService regAuthServiceClassObj; 
	
	@RequestMapping(value = "/register-security-Question.html", method = RequestMethod.GET)
	public String getregisterSecurityQuestionPage(Model model) {
		
		int numOfQuesToReg = regAuthServiceClassObj.getCountOfReqQuesToReg();
		List<KbaViewQuestionDto> kbaQuesAssListObj = regAuthServiceClassObj.getAllQuestionsKba();
		List<KbaSettingsDto> kbaQuesSettingListObj = regAuthServiceClassObj.getAllSettingsKba();
		model.addAttribute("numQuesToReg",numOfQuesToReg);
		model.addAttribute("securityQuesList",kbaQuesAssListObj);
		model.addAttribute("kbaQuesSettingListObj",kbaQuesSettingListObj);
		return "register-security-Question";
	}
	@RequestMapping(value = "/username.html", method = RequestMethod.GET)
	public String getUsernamePage() {
		
		return "username";
	}
	@RequestMapping(value = "/username.html", method = RequestMethod.POST)
	public String getUserPage(String username, Model model, HttpServletRequest request) {
		
		String result;
		HttpSession session = request.getSession();
		result = regAuthServiceClassObj.checkUsernameExist(username);
		if(result.equalsIgnoreCase("Username doesnot not exist"))
		{
			model.addAttribute("status", "Username doesnot not exist");
			return "username";
		}
		else if(result.equalsIgnoreCase("New User"))
		{
			session.setAttribute("usernameInUse", username);
			return "redirect:/changePassword.html";
		}
		else if(result.equalsIgnoreCase("Existing User"))
		{
			session.setAttribute("usernameInUse", username);
			return "redirect:/password.html";
		}
		else
		{
			model.addAttribute("status", "Something went wrong. Please try again.");
			return "username";
		}
	}
	@RequestMapping(value = "/changePassword.html", method = RequestMethod.GET)
	public String getChangePasswordPage(Model model) {
		
		List<PasswordSettingsDto> passSetListObj = regAuthServiceClassObj.getAllPasswordSetting();
		model.addAttribute("passSetListObj", passSetListObj);
		return "changePassword";
	}
	@RequestMapping(value = "/changePassword.html", method = RequestMethod.POST)
	public String changePassword(String newPassword, HttpServletRequest request, Model model) {
		
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("usernameInUse");
		if(username == null)
			return "redirect:/username";
		String result = regAuthServiceClassObj.updatePassword(newPassword, username);
		if(result.equalsIgnoreCase("Success"))
		{
			session.setAttribute("username", username);
			return "redirect:/register-mobile.htm";
		}
			
		else
		{
			model.addAttribute("STATUS", result);
			return "changePassword";
		}
	}
}