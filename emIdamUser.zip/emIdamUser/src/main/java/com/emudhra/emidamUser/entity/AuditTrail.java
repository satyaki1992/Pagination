package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class AuditTrail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 audit_trail_id;

	@Column
	private int	user_id;

	@Column
	private int app_id;

	@Column
	private int resource_id;

	@Column
	private int transaction_parameter_id;

	@Column
	private int transaction_parameter_value;

	@Column
	private int auth_type;

	@Column
	private String auth_value;

	@Column
	private String auth_success;

	@Column
	private String	policy_violation;

	@Column
	private String	ip_address;

	@Column
	private String	browser_type;

	@Column
	private String	operating_system;

	@Column
	private String	device_type;

	@Column
	private String	mac_address;

	@Column
	private String	hash_value;

	@Column
	private String	seq_hash_value;

	@Column
	private Date audit_trail_created_date;

	@Column
	private Date audit_trail_modified_date;

	@Column
	private int audit_trail_created_user;

	@Column
	private int audit_trail_modified_user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "audittrial", nullable = false)
	private UserMaster audittrial;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appMasterAuditTrail", nullable = false)
	private AppMaster appMasterAuditTrail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "authTypeMasterAuditTrail", nullable = false)
	private AuthenticationTypeMaster authTypeMasterAuditTrail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "txnParameterAuditTrail", nullable = false)
	private TransactionParameter txnParameterAuditTrail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "resourceMappingAuditTrail", nullable = false)
	private ResourceMapping resourceMappingAuditTrail;
	

	public ResourceMapping getResourceMappingAuditTrail() {
		return resourceMappingAuditTrail;
	}

	public void setResourceMappingAuditTrail(ResourceMapping resourceMappingAuditTrail) {
		this.resourceMappingAuditTrail = resourceMappingAuditTrail;
	}

	public TransactionParameter getTxnParameterAuditTrail() {
		return txnParameterAuditTrail;
	}

	public void setTxnParameterAuditTrail(TransactionParameter txnParameterAuditTrail) {
		this.txnParameterAuditTrail = txnParameterAuditTrail;
	}

	public AuthenticationTypeMaster getAuthTypeMasterAuditTrail() {
		return authTypeMasterAuditTrail;
	}

	public void setAuthTypeMasterAuditTrail(AuthenticationTypeMaster authTypeMasterAuditTrail) {
		this.authTypeMasterAuditTrail = authTypeMasterAuditTrail;
	}

	public UserMaster getAudittrial() {
		return audittrial;
	}

	public void setAudittrial(UserMaster audittrial) {
		this.audittrial = audittrial;
	}

	public AppMaster getAppMasterAuditTrail() {
		return appMasterAuditTrail;
	}

	public void setAppMasterAuditTrail(AppMaster appMasterAuditTrail) {
		this.appMasterAuditTrail = appMasterAuditTrail;
	}

	public int getAudit_trail_id() {
		return audit_trail_id;
	}

	public void setAudit_trail_id(int audit_trail_id) {
		this.audit_trail_id = audit_trail_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public int getResource_id() {
		return resource_id;
	}

	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}

	public int getTransaction_parameter_id() {
		return transaction_parameter_id;
	}

	public void setTransaction_parameter_id(int transaction_parameter_id) {
		this.transaction_parameter_id = transaction_parameter_id;
	}

	public int getTransaction_parameter_value() {
		return transaction_parameter_value;
	}

	public void setTransaction_parameter_value(int transaction_parameter_value) {
		this.transaction_parameter_value = transaction_parameter_value;
	}

	public int getAuth_type() {
		return auth_type;
	}

	public void setAuth_type(int auth_type) {
		this.auth_type = auth_type;
	}

	public String getAuth_value() {
		return auth_value;
	}

	public void setAuth_value(String auth_value) {
		this.auth_value = auth_value;
	}

	public String getAuth_success() {
		return auth_success;
	}

	public void setAuth_success(String auth_success) {
		this.auth_success = auth_success;
	}

	public String getPolicy_violation() {
		return policy_violation;
	}

	public void setPolicy_violation(String policy_violation) {
		this.policy_violation = policy_violation;
	}

	public String getIp_address() {
		return ip_address;
	}

	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}

	public String getBrowser_type() {
		return browser_type;
	}

	public void setBrowser_type(String browser_type) {
		this.browser_type = browser_type;
	}

	public String getOperating_system() {
		return operating_system;
	}

	public void setOperating_system(String operating_system) {
		this.operating_system = operating_system;
	}

	public String getDevice_type() {
		return device_type;
	}

	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}

	public String getMac_address() {
		return mac_address;
	}

	public void setMac_address(String mac_address) {
		this.mac_address = mac_address;
	}

	public String getHash_value() {
		return hash_value;
	}

	public void setHash_value(String hash_value) {
		this.hash_value = hash_value;
	}

	public String getSeq_hash_value() {
		return seq_hash_value;
	}

	public void setSeq_hash_value(String seq_hash_value) {
		this.seq_hash_value = seq_hash_value;
	}

	public Date getAudit_trail_created_date() {
		return audit_trail_created_date;
	}

	public void setAudit_trail_created_date(Date audit_trail_created_date) {
		this.audit_trail_created_date = audit_trail_created_date;
	}

	public Date getAudit_trail_modified_date() {
		return audit_trail_modified_date;
	}

	public void setAudit_trail_modified_date(Date audit_trail_modified_date) {
		this.audit_trail_modified_date = audit_trail_modified_date;
	}

	public int getAudit_trail_created_user() {
		return audit_trail_created_user;
	}

	public void setAudit_trail_created_user(int audit_trail_created_user) {
		this.audit_trail_created_user = audit_trail_created_user;
	}

	public int getAudit_trail_modified_user() {
		return audit_trail_modified_user;
	}

	public void setAudit_trail_modified_user(int audit_trail_modified_user) {
		this.audit_trail_modified_user = audit_trail_modified_user;
	}

}
