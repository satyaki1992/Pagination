package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "config_master")
public class ConfigMaster implements Serializable {
	private static final long serialVersionUID = 5166500712969986841L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int config_master_id;

	@Column
	private String config_key;

	@Column
	private String config_value;

	@Column
	private Date config_master_created_date;

	@Column
	private Date config_master_modified_date;

	@Column
	private int config_master_created_user;

	@Column
	private int config_master_modified_user;

	public int getConfig_master_id() {
		return config_master_id;
	}

	public void setConfig_master_id(int config_master_id) {
		this.config_master_id = config_master_id;
	}

	public String getConfig_key() {
		return config_key;
	}

	public void setConfig_key(String config_key) {
		this.config_key = config_key;
	}

	public String getConfig_value() {
		return config_value;
	}

	public void setConfig_value(String config_value) {
		this.config_value = config_value;
	}

	public Date getConfig_master_created_date() {
		return config_master_created_date;
	}

	public void setConfig_master_created_date(Date config_master_created_date) {
		this.config_master_created_date = config_master_created_date;
	}

	public Date getConfig_master_modified_date() {
		return config_master_modified_date;
	}

	public void setConfig_master_modified_date(Date config_master_modified_date) {
		this.config_master_modified_date = config_master_modified_date;
	}

	public int getConfig_master_created_user() {
		return config_master_created_user;
	}

	public void setConfig_master_created_user(int config_master_created_user) {
		this.config_master_created_user = config_master_created_user;
	}

	public int getConfig_master_modified_user() {
		return config_master_modified_user;
	}

	public void setConfig_master_modified_user(int config_master_modified_user) {
		this.config_master_modified_user = config_master_modified_user;
	}

}
