package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class CountryStateMapping implements Serializable {
	private static final long serialVersionUID = -3957276887289407954L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int state_id;

	@Column
	private int country_id;
	
	@Column
	private int country_state_created_user;

	@Column
	private int country_state_modified_user;

	@Column
	private String state_name;

	@Column
	private Date country_state_created_date;

	@Column
	private Date country_state_modified_date;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "stateCityMapping")
	private List<CityMaster> stateCityMapping = new ArrayList<CityMaster>();
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "countryMasterCountryStateMapping", nullable = false)
	private CountryMaster countryMasterCountryStateMapping;
	
	public CountryMaster getCountryMasterCountryStateMapping() {
		return countryMasterCountryStateMapping;
	}

	public void setCountryMasterCountryStateMapping(CountryMaster countryMasterCountryStateMapping) {
		this.countryMasterCountryStateMapping = countryMasterCountryStateMapping;
	}

	public int getCountry_id() {
		return country_id;
	}

	public void setCountry_id(int country_id) {
		this.country_id = country_id;
	}

	public int getState_id() {
		return state_id;
	}

	public void setState_id(int state_id) {
		this.state_id = state_id;
	}

	public int getCountry_state_created_user() {
		return country_state_created_user;
	}

	public void setCountry_state_created_user(int country_state_created_user) {
		this.country_state_created_user = country_state_created_user;
	}

	public int getCountry_state_modified_user() {
		return country_state_modified_user;
	}

	public void setCountry_state_modified_user(int country_state_modified_user) {
		this.country_state_modified_user = country_state_modified_user;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public Date getCountry_state_created_date() {
		return country_state_created_date;
	}

	public void setCountry_state_created_date(Date country_state_created_date) {
		this.country_state_created_date = country_state_created_date;
	}

	public Date getCountry_state_modified_date() {
		return country_state_modified_date;
	}

	public void setCountry_state_modified_date(Date country_state_modified_date) {
		this.country_state_modified_date = country_state_modified_date;
	}

	public List<CityMaster> getStateCityMapping() {
		return stateCityMapping;
	}

	public void setStateCityMapping(List<CityMaster> stateCityMapping) {
		this.stateCityMapping = stateCityMapping;
	}

}
