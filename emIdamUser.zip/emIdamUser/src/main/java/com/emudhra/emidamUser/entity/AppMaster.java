package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

@Entity
/*@NamedQueries(value = {
		@NamedQuery(name = "com.emudhra.idam.daoImpl.AppsMgrImpl.getAppApprover", query = "from com.emudhra.idam.entity.AppMaster appMaster where appMaster.app_name = :app_name") })
*/
public class AppMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int app_id;

	@Column(unique = true)
	private String app_name;

	@Column
	private Date app_created_date;

	@Column
	private Date app_modified_date;

	@Column
	private int app_created_user;

	@Column
	private int app_modified_user;

	@Column
	private String is_active = "Active";

	@Column
	private String is_deleted = "LIVE";

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "appapprovermapping")
	private List<AppApproverMapping> appapprovermapping = new ArrayList<AppApproverMapping>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "appipmapping")
	private List<AppIPMapping> appipmapping = new ArrayList<AppIPMapping>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "usrAccReqAppMasterId")
	private List<UserAccessRequest> usrAccReqAppMasterId = new ArrayList<UserAccessRequest>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "appMasterRiskProfiles")
	private List<RiskProfiles> appMasterRiskProfiles = new ArrayList<RiskProfiles>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "appMasterAuditTrail")
	private List<AuditTrail> appMasterAuditTrail = new ArrayList<AuditTrail>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userMasterAppMaster", nullable = true)
	private UserMaster userMasterAppMaster;

	public UserMaster getUserMasterAppMaster() {
		return userMasterAppMaster;
	}

	public void setUserMasterAppMaster(UserMaster userMasterAppMaster) {
		this.userMasterAppMaster = userMasterAppMaster;
	}

	public List<AuditTrail> getAppMasterAuditTrail() {
		return appMasterAuditTrail;
	}

	public void setAppMasterAuditTrail(List<AuditTrail> appMasterAuditTrail) {
		this.appMasterAuditTrail = appMasterAuditTrail;
	}

	public List<RiskProfiles> getAppMasterRiskProfiles() {
		return appMasterRiskProfiles;
	}

	public void setAppMasterRiskProfiles(List<RiskProfiles> appMasterRiskProfiles) {
		this.appMasterRiskProfiles = appMasterRiskProfiles;
	}

	public List<UserAccessRequest> getUsrAccReqAppMasterId() {
		return usrAccReqAppMasterId;
	}

	public void setUsrAccReqAppMasterId(List<UserAccessRequest> usrAccReqAppMasterId) {
		this.usrAccReqAppMasterId = usrAccReqAppMasterId;
	}

	public List<AppIPMapping> getAppipmapping() {
		return appipmapping;
	}

	public void setAppipmapping(List<AppIPMapping> appipmapping) {
		this.appipmapping = appipmapping;
	}

	public List<AppApproverMapping> getAppapprovermapping() {
		return appapprovermapping;
	}

	public void setAppapprovermapping(List<AppApproverMapping> appapprovermapping) {
		this.appapprovermapping = appapprovermapping;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public String getApp_name() {
		return app_name;
	}

	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	public Date getApp_created_date() {
		return app_created_date;
	}

	public void setApp_created_date(Date app_created_date) {
		this.app_created_date = app_created_date;
	}

	public Date getApp_modified_date() {
		return app_modified_date;
	}

	public void setApp_modified_date(Date app_modified_date) {
		this.app_modified_date = app_modified_date;
	}

	public int getApp_created_user() {
		return app_created_user;
	}

	public void setApp_created_user(int app_created_user) {
		this.app_created_user = app_created_user;
	}

	public int getApp_modified_user() {
		return app_modified_user;
	}

	public void setApp_modified_user(int app_modified_user) {
		this.app_modified_user = app_modified_user;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(String is_deleted) {
		this.is_deleted = is_deleted;
	}

}
