package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class RedirectURL implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int resource_id;

	@Column
	private String redirect_override;

	@Column
	private String access_denied_override;

	@Column
	private Date redirect_url_created_date;

	@Column
	private Date redirect_url_modified_date;

	@Column
	private int redirect_url_created_user;

	@Column
	private int redirect_url_modified_user;

	// @ManyToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "resourceMappingRedirectURL", nullable = false)
	// private ResourceMapping resourceMappingRedirectURL;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "redirectURL")
	private List<ResourceMapping> resourceMappingRedirectURL = new ArrayList<ResourceMapping>();

	public int getResource_id() {
		return resource_id;
	}

	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}

	public String getRedirect_override() {
		return redirect_override;
	}

	public void setRedirect_override(String redirect_override) {
		this.redirect_override = redirect_override;
	}

	public String getAccess_denied_override() {
		return access_denied_override;
	}

	public void setAccess_denied_override(String access_denied_override) {
		this.access_denied_override = access_denied_override;
	}

	public Date getRedirect_url_created_date() {
		return redirect_url_created_date;
	}

	public void setRedirect_url_created_date(Date redirect_url_created_date) {
		this.redirect_url_created_date = redirect_url_created_date;
	}

	public Date getRedirect_url_modified_date() {
		return redirect_url_modified_date;
	}

	public void setRedirect_url_modified_date(Date redirect_url_modified_date) {
		this.redirect_url_modified_date = redirect_url_modified_date;
	}

	public int getRedirect_url_created_user() {
		return redirect_url_created_user;
	}

	public void setRedirect_url_created_user(int redirect_url_created_user) {
		this.redirect_url_created_user = redirect_url_created_user;
	}

	public int getRedirect_url_modified_user() {
		return redirect_url_modified_user;
	}

	public void setRedirect_url_modified_user(int redirect_url_modified_user) {
		this.redirect_url_modified_user = redirect_url_modified_user;
	}

	public List<ResourceMapping> getResourceMappingRedirectURL() {
		return resourceMappingRedirectURL;
	}

	public void setResourceMappingRedirectURL(List<ResourceMapping> resourceMappingRedirectURL) {
		this.resourceMappingRedirectURL = resourceMappingRedirectURL;
	}

}
