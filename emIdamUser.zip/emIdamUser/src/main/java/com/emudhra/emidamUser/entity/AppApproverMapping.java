package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class AppApproverMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 app_id;
	
	@Column
	private int	approver_id;
	
	@Column
	private Date app_approver_created_date;
	
	@Column
	private Date app_approver_modified_date;
	
	@Column
	private int	app_approver_created_user;
	
	@Column
	private int	app_approver_modified_user;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appapprovermapping", nullable = false)
	private AppMaster appapprovermapping;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appapprovrmap_dtls", nullable = false)
	private UserMaster appapprovrmap_dtls;
	

	public AppMaster getAppapprovermapping() {
		return appapprovermapping;
	}

	public void setAppapprovermapping(AppMaster appapprovermapping) {
		this.appapprovermapping = appapprovermapping;
	}

	public UserMaster getAppapprovrmap_dtls() {
		return appapprovrmap_dtls;
	}

	public void setAppapprovrmap_dtls(UserMaster appapprovrmap_dtls) {
		this.appapprovrmap_dtls = appapprovrmap_dtls;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public int getApprover_id() {
		return approver_id;
	}

	public void setApprover_id(int approver_id) {
		this.approver_id = approver_id;
	}

	public Date getApp_approver_created_date() {
		return app_approver_created_date;
	}

	public void setApp_approver_created_date(Date app_approver_created_date) {
		this.app_approver_created_date = app_approver_created_date;
	}

	public Date getApp_approver_modified_date() {
		return app_approver_modified_date;
	}

	public void setApp_approver_modified_date(Date app_approver_modified_date) {
		this.app_approver_modified_date = app_approver_modified_date;
	}

	public int getApp_approver_created_user() {
		return app_approver_created_user;
	}

	public void setApp_approver_created_user(int app_approver_created_user) {
		this.app_approver_created_user = app_approver_created_user;
	}

	public int getApp_approver_modified_user() {
		return app_approver_modified_user;
	}

	public void setApp_approver_modified_user(int app_approver_modified_user) {
		this.app_approver_modified_user = app_approver_modified_user;
	}

	
}
