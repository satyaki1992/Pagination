package com.emudhra.emidamUser.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.emudhra.emidamUser.constants.IdamUserConstants;
import com.emudhra.emidamUser.formData.MobRegAuthForm;
import com.emudhra.emidamUser.service.RegisterAuthenticationService;
import com.emudhra.emidamUser.service.SMSOTPService;

@Controller
public class SMSOTPController {
	@Autowired
	SMSOTPService mobService;
	
	@Autowired
	RegisterAuthenticationService regAuthServClassObj; 

	@RequestMapping(value = "/registermobile.htm")
	public String registerMobile(HttpSession session) {
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		String mobNo = mobService.findMobileNumber(userId);
		if (mobNo.equals(IdamUserConstants.MOBNO_NOT_REG)) 
			return "register-mobile";
		else {
			mobService.sendMobileOTP(userId, mobNo);
			session.setAttribute((String) session.getAttribute("username")+"_MobNo", mobNo);
			return "register-mobile-otp";
		}
	}

	@RequestMapping(value = "/registermobile.htm", method = RequestMethod.POST)
	public ModelAndView registerMobileNumber(MobRegAuthForm form , HttpSession session) {
		/*if (!validateSession(session)) {
			return "login";
		}*/
		ModelAndView mav = new ModelAndView("mobile-otp-auth");
		String mobNo = form.getMobileNo();
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		session.setAttribute(username+"_MobNo", mobNo);
		mobService.saveMobileNumber(Integer.valueOf(userId), mobNo);
		mobService.sendMobileOTP(userId, mobNo);
		mav.addObject("mobNumber", mobNo.substring(mobNo.length() - 3));
		return mav;
	}
	
	@RequestMapping(value = "/resendotp.htm")
	public ModelAndView resendMobileOTP(HttpSession session) {
		ModelAndView mav = new ModelAndView("mobile-otp-auth");
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		String mobNo = (String)session.getAttribute(username+"_MobNo");
		mobService.sendMobileOTP(userId, mobNo);
		mav.addObject("mobNumber", mobNo.substring(mobNo.length() - 3));
		return mav;
	}
	
	@RequestMapping(value = "/authenticate.htm", method=RequestMethod.POST)
	public String authenticateUser(MobRegAuthForm form, HttpSession session) {
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		boolean status = mobService.authenticate(userId, form.getAuthCode());
		if(!status){
			return null;
		}
		System.out.println("Authenticated Successfully");
		return "";
	}
	
	@RequestMapping(value = "/emailotp.htm")
	public ModelAndView sendEmailOtp(HttpSession session) {
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		String email = mobService.sendEmailOTP(Integer.valueOf(userId));
		ModelAndView mav = new ModelAndView("email-otp-auth");
		String[] parts = email.split("@");
		mav.addObject("email", parts[0].substring(parts[0].length() - 3)+"@"+parts[1]);
		return mav;
	}
	
	@RequestMapping(value = "/resendemailotp.htm")
	public ModelAndView resendEmailOTP(HttpSession session) {
		ModelAndView mav = new ModelAndView("email-otp-auth");
		String username = (String)session.getAttribute("username");
		String userId = regAuthServClassObj.getUserId(username);
		String email = mobService.sendEmailOTP(Integer.valueOf(userId));
		String[] parts = email.split("@");
		mav.addObject("email", parts[0].substring(parts[0].length() - 3)+"@"+parts[1]);
		return mav;
	}
	
	private boolean validateSession(HttpSession session) {
		if (session == null) {
			return false;
		} else {
			String userId = (String) session.getAttribute("username");
			if (userId == null) {
				return false;
			}
			return true;
		}
	}
	
	public static void main(String[] args) {
		String str = "Kedarnath.p@emudhra.com";
		String substr = "@";
		String[] parts = str.split(substr);
		String before = parts[0];
		String after = parts[1];
		System.out.println(before.substring(before.length() - 3)+"\n"+after);
	}
}
