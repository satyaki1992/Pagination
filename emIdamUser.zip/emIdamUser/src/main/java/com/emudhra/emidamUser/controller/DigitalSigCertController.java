package com.emudhra.emidamUser.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DigitalSigCertController {
	
	@RequestMapping("registerdsc.htm")
	public String registerDsc() {
		return "register-dsc";
	}
}
