package com.emudhra.emidamUser.service;

import java.util.List;

import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.formData.LoginForm;

public interface AuthenticateAuthenticationService {
	
	boolean isUserValid(LoginForm loginForm);

	List<KbaViewQuestionDto> getKbaQuesForAuth(int pageRowstart, int numRowFromStart, String username);

	String getTotalCountQuesShow();
}
