package com.emudhra.emidamUser.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emudhra.emidamUser.dao.SMSOTPAuthDao;
import com.emudhra.emidamUser.service.SMSOTPService;

@Service
public class SMSOTPServiceImpl implements SMSOTPService {
	@Autowired
	SMSOTPAuthDao mobAuthDao;

	@Override
	public void sendMobileOTP(String custID, String mobileNo) {
		mobAuthDao.sendMobileOTP(custID, mobileNo);
	}

	@Override
	public boolean authenticate(String custID, String verificationCode) {
		return mobAuthDao.authenticate(custID, verificationCode);
	}

	@Override
	public String findMobileNumber(String id) {
		return mobAuthDao.findMobileNumber(id);
	}

	@Override
	public void saveMobileNumber(int userId, String mobNo) {
		mobAuthDao.saveMobileNumber(userId, mobNo);
	}

	@Override
	public String sendEmailOTP(int userId) {
		return mobAuthDao.sendEmailOTP(userId);
	}

}
