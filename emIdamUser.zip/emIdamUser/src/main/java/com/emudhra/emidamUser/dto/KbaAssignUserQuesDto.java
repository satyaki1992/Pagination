package com.emudhra.emidamUser.dto;

import java.util.List;

public class KbaAssignUserQuesDto {
	
	private List<Integer> quesArray;
    private List<String> ansArray;
	public List<Integer> getQuesArray() {
		return quesArray;
	}
	public void setQuesArray(List<Integer> quesArray) {
		this.quesArray = quesArray;
	}
	public List<String> getAnsArray() {
		return ansArray;
	}
	public void setAnsArray(List<String> ansArray) {
		this.ansArray = ansArray;
	}
	  
}
