package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class AuthenticationValueMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 authentication_value_id;
	
	@Column
	private int	auth_type_id;
	
	@Column
	private String auth_val_name;
	
	@Column
	private String authentication_value;
		
	@Column
	private Date auth_val_created_date;
	
	@Column
	private Date auth_val_modified_date;
	
	@Column
	private int	auth_val_created_user;
	
	@Column
	private int	auth_val_modified_user;
	
	@Column
	private String	auth_val_rank;
	
	@Column
	private String	auth_val_status;
	
	@Column
	private String	auth_val_flag;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "authenticationValueMapping", nullable = true)
	private AuthenticationTypeMaster authenticationValueMapping;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userEnrollmentDetailsAuthValMap")
	private List<UserEnrollmentDetails> userEnrollmentDetailsAuthValMap = new ArrayList<UserEnrollmentDetails>();
 	
	public String getAuth_val_rank() {
		return auth_val_rank;
	}

	public void setAuth_val_rank(String auth_val_rank) {
		this.auth_val_rank = auth_val_rank;
	}

	public String getAuth_val_status() {
		return auth_val_status;
	}

	public void setAuth_val_status(String auth_val_status) {
		this.auth_val_status = auth_val_status;
	}

	public List<UserEnrollmentDetails> getUserEnrollmentDetailsAuthValMap() {
		return userEnrollmentDetailsAuthValMap;
	}

	public void setUserEnrollmentDetailsAuthValMap(List<UserEnrollmentDetails> userEnrollmentDetailsAuthValMap) {
		this.userEnrollmentDetailsAuthValMap = userEnrollmentDetailsAuthValMap;
	}

	public AuthenticationTypeMaster getAuthenticationValueMapping() {
		return authenticationValueMapping;
	}

	public void setAuthenticationValueMapping(AuthenticationTypeMaster authenticationValueMapping) {
		this.authenticationValueMapping = authenticationValueMapping;
	}

	public int getAuthentication_value_id() {
		return authentication_value_id;
	}

	public void setAuthentication_value_id(int authentication_value_id) {
		this.authentication_value_id = authentication_value_id;
	}

	public int getAuth_type_id() {
		return auth_type_id;
	}

	public void setAuth_type_id(int auth_type_id) {
		this.auth_type_id = auth_type_id;
	}

	public String getAuth_val_name() {
		return auth_val_name;
	}

	public void setAuth_val_name(String auth_val_name) {
		this.auth_val_name = auth_val_name;
	}

	public String getAuthentication_value() {
		return authentication_value;
	}

	public void setAuthentication_value(String authentication_value) {
		this.authentication_value = authentication_value;
	}

	public Date getAuth_val_created_date() {
		return auth_val_created_date;
	}

	public void setAuth_val_created_date(Date auth_val_created_date) {
		this.auth_val_created_date = auth_val_created_date;
	}

	public Date getAuth_val_modified_date() {
		return auth_val_modified_date;
	}

	public void setAuth_val_modified_date(Date auth_val_modified_date) {
		this.auth_val_modified_date = auth_val_modified_date;
	}

	public int getAuth_val_created_user() {
		return auth_val_created_user;
	}

	public void setAuth_val_created_user(int auth_val_created_user) {
		this.auth_val_created_user = auth_val_created_user;
	}

	public int getAuth_val_modified_user() {
		return auth_val_modified_user;
	}

	public void setAuth_val_modified_user(int auth_val_modified_user) {
		this.auth_val_modified_user = auth_val_modified_user;
	}

	
}
