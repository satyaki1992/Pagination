package com.emudhra.emidamUser.dao;

import java.util.List;

import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.entity.UserMaster;
import com.emudhra.emidamUser.formData.LoginForm;

public interface AuthenticateAuthenticationDao {
	
	boolean isUserValid(LoginForm loginForm);

	List<KbaViewQuestionDto> getKbaQuesForAuth(int pageRowstart, int numRowFromStart, int userId);

	String getTotalCountQuesShow();
}
