package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CountryMaster implements Serializable {
	private static final long serialVersionUID = 941670480370865401L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int country_id;

	@Column
	private String country_code;

	@Column
	private String country_name;

	@Column
	private Date country_created_date;

	@Column
	private Date country_modified_date;

	@Column
	private int country_created_user;

	@Column
	private int country_modified_user;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "countryMasterCountryStateMapping")
	private List<CountryStateMapping> countryMasterCountryStateMapping = new ArrayList<CountryStateMapping>();

	public List<CountryStateMapping> getCountryMasterCountryStateMapping() {
		return countryMasterCountryStateMapping;
	}

	public void setCountryMasterCountryStateMapping(List<CountryStateMapping> countryMasterCountryStateMapping) {
		this.countryMasterCountryStateMapping = countryMasterCountryStateMapping;
	}

	public int getCountry_id() {
		return country_id;
	}

	public void setCountry_id(int country_id) {
		this.country_id = country_id;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public String getCountry_name() {
		return country_name;
	}

	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

	public Date getCountry_created_date() {
		return country_created_date;
	}

	public void setCountry_created_date(Date country_created_date) {
		this.country_created_date = country_created_date;
	}

	public Date getCountry_modified_date() {
		return country_modified_date;
	}

	public void setCountry_modified_date(Date country_modified_date) {
		this.country_modified_date = country_modified_date;
	}

	public int getCountry_created_user() {
		return country_created_user;
	}

	public void setCountry_created_user(int country_created_user) {
		this.country_created_user = country_created_user;
	}

	public int getCountry_modified_user() {
		return country_modified_user;
	}

	public void setCountry_modified_user(int country_modified_user) {
		this.country_modified_user = country_modified_user;
	}

}
