package com.emudhra.emidamUser.dto;

public class KbaViewQuestionDto {
	
	private int authentication_value_id;
	private String authentication_value;
	
	public KbaViewQuestionDto(Object authentication_value_id, Object authentication_value) {
		this.authentication_value_id = (int)authentication_value_id;
		this.authentication_value = (String)authentication_value;
	}

	public int getAuthentication_value_id() {
		return authentication_value_id;
	}

	public String getAuthentication_value() {
		return authentication_value;
	}
}
