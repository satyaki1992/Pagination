package com.emudhra.emidamUser.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.emudhra.emidamUser.constants.IdamUserConstants;
import com.emudhra.emidamUser.dao.RegisterAuthenticationDao;
import com.emudhra.emidamUser.entity.AuthenticationValueMapping;
import com.emudhra.emidamUser.entity.UserEnrollmentDetails;
import com.emudhra.emidamUser.entity.UserMaster;

@Transactional
@Repository
public class RegisterAuthenticationDaoImpl implements RegisterAuthenticationDao{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean registerSecurityQuestion(List<UserEnrollmentDetails> userDetListObj) {
		
		try
		{
			for(UserEnrollmentDetails loop: userDetListObj)
			{
				entityManager.persist(loop);
			}
		}
		catch(Exception e)
		{
			return false;
		}
		
		return true;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthenticationValueMapping> getAllQuestionsKba() {
		
		int auth_type_id = Integer.parseInt(IdamUserConstants.KBA);
		List<AuthenticationValueMapping> authValListObj = new ArrayList<>();
		String query="FROM AuthenticationValueMapping where auth_type_id=:auth_type_id and auth_val_name=:auth_val_name";
		authValListObj = entityManager.createQuery(query)
					.setParameter("auth_type_id", auth_type_id)
					.setParameter("auth_val_name", "Question")
					.getResultList();
		return authValListObj;
	}
	@Override
	public AuthenticationValueMapping getCountOfReqQuesToReg() {
		int auth_type_id = Integer.parseInt(IdamUserConstants.KBA);
		AuthenticationValueMapping authValClassObj = new AuthenticationValueMapping();
		
		String query="FROM AuthenticationValueMapping where auth_type_id=:auth_type_id and auth_val_name=:auth_val_name";
		authValClassObj = (AuthenticationValueMapping) entityManager.createQuery(query)
					.setParameter("auth_type_id", auth_type_id)
					.setParameter("auth_val_name", "Settings-QuestionToRegister")
					.getResultList().get(0);
		return authValClassObj;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthenticationValueMapping> getAllSettingsKba() {
		List<String> listAuthVal = new ArrayList<>();
		listAuthVal.add("Settings-QuestionToRegister");
		listAuthVal.add("Settings-QuestionToDisplay");
		listAuthVal.add("Settings-Numeric");
		listAuthVal.add("Settings-SpecialCharacters");
		listAuthVal.add("Settings-CharLimitAnswer");
		listAuthVal.add("Settings-MaxCharAns");
		listAuthVal.add("Settings-MinCharAns");
		listAuthVal.add("Settings-SameAnsMulQues");
		listAuthVal.add("Settings-NoQuesWordInAnswer");
		listAuthVal.add("Settings-AlgoReqOrNotToStoreAns");
		listAuthVal.add("Settings-AlgoNameForAns");
		String query = "From AuthenticationValueMapping where auth_type_id=:auth_type_id and auth_val_name in (:listOfAuthSettings)";
		List<AuthenticationValueMapping> authValMapListObj = entityManager.createQuery(query)
				.setParameter("auth_type_id", Integer.parseInt(IdamUserConstants.KBA))
				.setParameter("listOfAuthSettings", listAuthVal)
				.getResultList();
		return authValMapListObj;
	}
	@SuppressWarnings("unchecked")
	@Override
	public String checkUsernameExist(String username) {
		
		String query;
		query = "FROM UserMaster where user_name=:user_name";
		List<UserMaster> listUserName = entityManager.createQuery(query)
				.setParameter("user_name", username)
				.getResultList();
		query = "FROM UserMaster where user_name=:user_name and user_Password is NULL";
		List<UserMaster> listNewUserName = entityManager.createQuery(query)
				.setParameter("user_name", username)
				.getResultList();
		query = "FROM UserMaster where user_name=:user_name and user_Password is NOT NULL";
		List<UserMaster> listOldUserName = entityManager.createQuery(query)
				.setParameter("user_name", username)
				.getResultList();
		if(listUserName.size() > 0)
		{
			if(listNewUserName.size() > 0)
				return "New User";
			else if(listOldUserName.size() > 0)
				return "Existing User";
		}
		else
			return "Username doesnot not exist";
		return "Something went wrong";
	}
	@SuppressWarnings("unchecked")
	@Override
	public String updatePassword(String newPassword, String username) {
		
		String query;
		query = "FROM UserMaster where user_name=:user_name";
		List<UserMaster> listUserName = entityManager.createQuery(query)
				.setParameter("user_name", username)
				.getResultList();
		query = "update UserMaster set user_Password=:user_Password, active_flag=:active_flag, user_Status=:user_Status"
				+ " where user_name=:user_name";
		int rowsReturn = entityManager.createQuery(query)
				.setParameter("user_Password", newPassword)
				.setParameter("active_flag", IdamUserConstants.ISACTIVE)
				.setParameter("user_Status", IdamUserConstants.ISLIVE)
				.setParameter("user_name", username)
				.executeUpdate();
		if(listUserName.size() > 0)
		{
			if(rowsReturn > 0)
				return "Success";
			else
				return "Failure";
		}
		else
			return "Username doesnot not exist";
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<AuthenticationValueMapping> getAllSettingsPassword() {
		List<String> listAuthVal = new ArrayList<>();
		listAuthVal.add("Settings-Password-passwordLenMin");
		listAuthVal.add("Settings-Password-passwordLenMax");
		listAuthVal.add("Settings-Password-numericLenMin");
		listAuthVal.add("Settings-Password-numericLenMax");
		listAuthVal.add("Settings-Password-upperCaseLenMin");
		listAuthVal.add("Settings-Password-upperCaseLenMax");
		listAuthVal.add("Settings-Password-lowerCaseLenMin");
		listAuthVal.add("Settings-Password-lowerCaseLenMax");
		
		String query = "From AuthenticationValueMapping where auth_type_id=:auth_type_id and auth_val_name in (:listOfAuthSettings)";
		List<AuthenticationValueMapping> passwordOtpSettListObj = entityManager.createQuery(query)
				.setParameter("auth_type_id", Integer.parseInt(IdamUserConstants.PASSWORD))
				.setParameter("listOfAuthSettings", listAuthVal)
				.getResultList();
		return passwordOtpSettListObj;
	}
	@SuppressWarnings("unchecked")
	@Override
	public int getUserId(String username) {
		
		String query = "FROM UserMaster where user_name=:username";
		List<UserMaster> userMasRes = entityManager.createQuery(query).setParameter("username", username).getResultList();
		UserMaster userMasterObj = userMasRes.get(0);
		int userid = userMasterObj.getUser_id();
		return userid;
	}
}