package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class TransactionParameter implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 624039313787487102L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int txn_parameter_id;

	@Column
	private String parameter_name;

	@Column
	private int app_id;

	@Column
	private Date parameter_created_date;

	@Column
	private Date parameter_modified_date;

	@Column
	private int parameter_created_user;

	@Column
	private int parameter_modified_user;

	@Column
	private String parameter_type;

	@Column
	private String is_active = "Active";

	@Column
	private String is_deleted = "LIVE";

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "txnParameterAuditTrail")
	private List<AuditTrail> txnParameterAuditTrail = new ArrayList<AuditTrail>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "txnParameterRiskProfiles")
	private List<RiskProfiles> txnParameterRiskProfiles = new ArrayList<RiskProfiles>();

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "operatorMasterTxnParameter")
	private OperatorMaster operatorMasterTxnParameter;

	public OperatorMaster getOperatorMasterTxnParameter() {
		return operatorMasterTxnParameter;
	}

	public void setOperatorMasterTxnParameter(OperatorMaster operatorMasterTxnParameter) {
		this.operatorMasterTxnParameter = operatorMasterTxnParameter;
	}

	public List<RiskProfiles> getTxnParameterRiskProfiles() {
		return txnParameterRiskProfiles;
	}

	public void setTxnParameterRiskProfiles(List<RiskProfiles> txnParameterRiskProfiles) {
		this.txnParameterRiskProfiles = txnParameterRiskProfiles;
	}

	public List<AuditTrail> getTxnParameterAuditTrail() {
		return txnParameterAuditTrail;
	}

	public void setTxnParameterAuditTrail(List<AuditTrail> txnParameterAuditTrail) {
		this.txnParameterAuditTrail = txnParameterAuditTrail;
	}

	public int getTxn_parameter_id() {
		return txn_parameter_id;
	}

	public void setTxn_parameter_id(int txn_parameter_id) {
		this.txn_parameter_id = txn_parameter_id;
	}

	public String getParameter_name() {
		return parameter_name;
	}

	public void setParameter_name(String parameter_name) {
		this.parameter_name = parameter_name;
	}

	public Date getParameter_created_date() {
		return parameter_created_date;
	}

	public void setParameter_created_date(Date parameter_created_date) {
		this.parameter_created_date = parameter_created_date;
	}

	public Date getParameter_modified_date() {
		return parameter_modified_date;
	}

	public void setParameter_modified_date(Date parameter_modified_date) {
		this.parameter_modified_date = parameter_modified_date;
	}

	public int getParameter_created_user() {
		return parameter_created_user;
	}

	public void setParameter_created_user(int parameter_created_user) {
		this.parameter_created_user = parameter_created_user;
	}

	public int getParameter_modified_user() {
		return parameter_modified_user;
	}

	public void setParameter_modified_user(int parameter_modified_user) {
		this.parameter_modified_user = parameter_modified_user;
	}

	public String getParameter_type() {
		return parameter_type;
	}

	public void setParameter_type(String parameter_type) {
		this.parameter_type = parameter_type;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public String getIs_active() {
		return is_active;
	}

	public void setIs_active(String is_active) {
		this.is_active = is_active;
	}

	public String getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(String is_deleted) {
		this.is_deleted = is_deleted;
	}

}
