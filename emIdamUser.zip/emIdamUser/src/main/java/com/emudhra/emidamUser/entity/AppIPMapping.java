package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class AppIPMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 app_id;

	@Column
	private String	whitelisted_ip;

	@Column
	private Date app_ip_mapping_created_date;

	@Column
	private Date app_ip_mapping_modified_date;

	@Column
	private int	app_ip_mapping_created_user;

	@Column
	private int	app_ip_mapping_modified_user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appipmapping", nullable = false)
	private AppMaster appipmapping;
	
	public AppMaster getAppipmapping() {
		return appipmapping;
	}

	public void setAppipmapping(AppMaster appipmapping) {
		this.appipmapping = appipmapping;
	}

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}

	public String getWhitelisted_ip() {
		return whitelisted_ip;
	}

	public void setWhitelisted_ip(String whitelisted_ip) {
		this.whitelisted_ip = whitelisted_ip;
	}

	public Date getApp_ip_mapping_created_date() {
		return app_ip_mapping_created_date;
	}

	public void setApp_ip_mapping_created_date(Date app_ip_mapping_created_date) {
		this.app_ip_mapping_created_date = app_ip_mapping_created_date;
	}

	public Date getApp_ip_mapping_modified_date() {
		return app_ip_mapping_modified_date;
	}

	public void setApp_ip_mapping_modified_date(Date app_ip_mapping_modified_date) {
		this.app_ip_mapping_modified_date = app_ip_mapping_modified_date;
	}

	public int getApp_ip_mapping_created_user() {
		return app_ip_mapping_created_user;
	}

	public void setApp_ip_mapping_created_user(int app_ip_mapping_created_user) {
		this.app_ip_mapping_created_user = app_ip_mapping_created_user;
	}

	public int getApp_ip_mapping_modified_user() {
		return app_ip_mapping_modified_user;
	}

	public void setApp_ip_mapping_modified_user(int app_ip_mapping_modified_user) {
		this.app_ip_mapping_modified_user = app_ip_mapping_modified_user;
	}

}
