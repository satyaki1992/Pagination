package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
/*@NamedQueries(value = { 
		@NamedQuery(name = "com.emudhra.idam.daoImpl.UserMasterMgrImpl.getUsers", 
				    query = "from com.emudhra.idam.entity.UserMaster userMaster where userMaster.user_name = :user_name")
   })*/
public class UserMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "user_id", unique = true, nullable = true)
	private int user_id;

	@Column
	private String user_state;

	@Column
	private int user_country_id;

	@Column
	private String user_created_user;

	@Column
	private String user_modified_user;

	@Column
	private Date user_created_date;

	@Column
	private Date user_modified_date;

	@Column(unique=true, nullable=false)
	private String user_name;

	@Column
	private String user_address_line1;

	@Column
	private String user_address_line2;

	@Column
	private String user_city;

	@Column
	private String user_county;

	@Column
	private String user_organization;

	@Column
	private String user_department;

	@Column
	private String user_dob;

	@Column(unique=true, nullable=false)
	private String user_email_id;

	@Column
	private String user_emp_id;

	@Column
	private String user_creation_type;

	@Column
	private String active_flag;

	@Column(unique=true, nullable=false)
	private String user_mobile_number;
	
	@Column
	private String user_gender;
	
	@Column
	private String user_role;
	
	@Column
	private String user_zipCode;
	
	@Column
	private String user_Password;
	
	@Column
	private String user_Status;
	
	@Column
	private String user_Flag;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "appapprovrmap_dtls")
	private List<AppApproverMapping> appapprovrmap = new ArrayList<AppApproverMapping>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userenrollment_dtls")
	private List<UserEnrollmentDetails> userenrollment_dtls = new ArrayList<UserEnrollmentDetails>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "audittrial")
	private List<AuditTrail> audittrial = new ArrayList<AuditTrail>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "riskprofiles")
	private List<RiskProfiles> riskprofiles = new ArrayList<RiskProfiles>();
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "userAccessRequest")
	private List<UserAccessRequest> userAccessRequest = new ArrayList<UserAccessRequest>();
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "usergroupmapping")
	private List<UserGroupMapping> usergroupmapping = new ArrayList<UserGroupMapping>();
	
	
	@Column(name="user_AppMasterId")
	@OneToMany(targetEntity = AppMaster.class, mappedBy = "userMasterAppMaster", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonBackReference(value="userMasterAppMaster")
	private List<AppMaster> userMasterAppMaster = new ArrayList<AppMaster>();
	


	public String getUser_state() {
		return user_state;
	}

	public void setUser_state(String user_state) {
		this.user_state = user_state;
	}

	public String getUser_created_user() {
		return user_created_user;
	}

	public void setUser_created_user(String user_created_user) {
		this.user_created_user = user_created_user;
	}

	public String getUser_modified_user() {
		return user_modified_user;
	}

	public void setUser_modified_user(String user_modified_user) {
		this.user_modified_user = user_modified_user;
	}

	public String getUser_Flag() {
		return user_Flag;
	}

	public void setUser_Flag(String user_Flag) {
		this.user_Flag = user_Flag;
	}

	public String getUser_Password() {
		return user_Password;
	}

	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}

	public String getUser_Status() {
		return user_Status;
	}

	public void setUser_Status(String user_Status) {
		this.user_Status = user_Status;
	}
	
	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public String getUser_zipCode() {
		return user_zipCode;
	}

	public void setUser_zipCode(String user_zipCode) {
		this.user_zipCode = user_zipCode;
	}

	public List<AppMaster> getUserMasterAppMaster() {
		return userMasterAppMaster;
	}

	public void setUserMasterAppMaster(List<AppMaster> userMasterAppMaster) {
		this.userMasterAppMaster = userMasterAppMaster;
	}

	public List<UserGroupMapping> getUsergroupmapping() {
		return usergroupmapping;
	}

	public void setUsergroupmapping(List<UserGroupMapping> usergroupmapping) {
		this.usergroupmapping = usergroupmapping;
	}

	public List<UserAccessRequest> getUserAccessRequest() {
		return userAccessRequest;
	}

	public void setUserAccessRequest(List<UserAccessRequest> userAccessRequest) {
		this.userAccessRequest = userAccessRequest;
	}

	public List<RiskProfiles> getRiskprofiles() {
		return riskprofiles;
	}

	public void setRiskprofiles(List<RiskProfiles> riskprofiles) {
		this.riskprofiles = riskprofiles;
	}

	public List<AuditTrail> getAudittrial() {
		return audittrial;
	}

	public void setAudittrial(List<AuditTrail> audittrial) {
		this.audittrial = audittrial;
	}

	public List<AppApproverMapping> getAppapprovrmap() {
		return appapprovrmap;
	}

	public void setAppapprovrmap(List<AppApproverMapping> appapprovrmap) {
		this.appapprovrmap = appapprovrmap;
	}

	public List<UserEnrollmentDetails> getUserenrollment_dtls() {
		return userenrollment_dtls;
	}

	public void setUserenrollment_dtls(List<UserEnrollmentDetails> userenrollment_dtls) {
		this.userenrollment_dtls = userenrollment_dtls;
	}

	public String getUser_mobile_number() {
		return user_mobile_number;
	}

	public void setUser_mobile_number(String user_mobile_number) {
		this.user_mobile_number = user_mobile_number;
	}

	public String getUser_gender() {
		return user_gender;
	}

	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getUser_country_id() {
		return user_country_id;
	}

	public void setUser_country_id(int user_country_id) {
		this.user_country_id = user_country_id;
	}

	public Date getUser_created_date() {
		return user_created_date;
	}

	public void setUser_created_date(Date user_created_date) {
		this.user_created_date = user_created_date;
	}

	public Date getUser_modified_date() {
		return user_modified_date;
	}

	public void setUser_modified_date(Date user_modified_date) {
		this.user_modified_date = user_modified_date;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_address_line1() {
		return user_address_line1;
	}

	public void setUser_address_line1(String user_address_line1) {
		this.user_address_line1 = user_address_line1;
	}

	public String getUser_address_line2() {
		return user_address_line2;
	}

	public void setUser_address_line2(String user_address_line2) {
		this.user_address_line2 = user_address_line2;
	}

	public String getUser_city() {
		return user_city;
	}

	public void setUser_city(String user_city) {
		this.user_city = user_city;
	}

	public String getUser_county() {
		return user_county;
	}

	public void setUser_county(String user_county) {
		this.user_county = user_county;
	}

	public String getUser_organization() {
		return user_organization;
	}

	public void setUser_organization(String user_organization) {
		this.user_organization = user_organization;
	}

	public String getUser_department() {
		return user_department;
	}

	public void setUser_department(String user_department) {
		this.user_department = user_department;
	}

	public String getUser_dob() {
		return user_dob;
	}

	public void setUser_dob(String user_dob) {
		this.user_dob = user_dob;
	}

	public String getUser_email_id() {
		return user_email_id;
	}

	public void setUser_email_id(String user_email_id) {
		this.user_email_id = user_email_id;
	}

	public String getUser_emp_id() {
		return user_emp_id;
	}

	public void setUser_emp_id(String user_emp_id) {
		this.user_emp_id = user_emp_id;
	}

	public String getUser_creation_type() {
		return user_creation_type;
	}

	public void setUser_creation_type(String user_creation_type) {
		this.user_creation_type = user_creation_type;
	}

	public String getActive_flag() {
		return active_flag;
	}

	public void setActive_flag(String active_flag) {
		this.active_flag = active_flag;
	}

}
