package com.emudhra.emidamUser.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
@Configuration
@EnableAutoConfiguration
public class SpringServletConfig {
	@Bean
	public InternalResourceViewResolver resolver() {
		InternalResourceViewResolver vr = new InternalResourceViewResolver();
		vr.setPrefix("/view/jsp/");
		vr.setSuffix(".jsp");
		return vr;
	}

	@Bean
	public StringHttpMessageConverter messageConverter() {
		StringHttpMessageConverter converter = new StringHttpMessageConverter();
		return converter;
	}

	@Bean
	public MappingJackson2HttpMessageConverter httpMessageConverter() {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
		return converter;
	}
}
