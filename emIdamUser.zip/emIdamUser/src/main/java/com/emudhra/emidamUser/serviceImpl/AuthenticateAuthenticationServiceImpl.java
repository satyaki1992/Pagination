package com.emudhra.emidamUser.serviceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emudhra.emidamUser.dao.AuthenticateAuthenticationDao;
import com.emudhra.emidamUser.dao.RegisterAuthenticationDao;
import com.emudhra.emidamUser.dto.KbaViewQuestionDto;
import com.emudhra.emidamUser.entity.UserMaster;
import com.emudhra.emidamUser.formData.LoginForm;
import com.emudhra.emidamUser.service.AuthenticateAuthenticationService;
import com.emudhra.emidamUser.util.EncryptAndDecryptUtil;

@Service
public class AuthenticateAuthenticationServiceImpl implements AuthenticateAuthenticationService{
	
	@Autowired
	AuthenticateAuthenticationDao authDao;
	@Autowired
	RegisterAuthenticationDao regAuthDaoClassObj;
	@Autowired
	EncryptAndDecryptUtil encryptAndDecryptUtil;
	
	@Override
	public boolean isUserValid(LoginForm loginForm) {
		
		String encryptedPassword = encryptAndDecryptUtil.createHash(loginForm.getPassword());
		if(encryptedPassword == null) {
			return false;
		}
		loginForm.setPassword(encryptedPassword);
		boolean result = authDao.isUserValid(loginForm);
		return result;	
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<KbaViewQuestionDto> getKbaQuesForAuth(int pageRowstart, int numRowFromStart, String username) {
		
		int userId = regAuthDaoClassObj.getUserId(username);
		List<KbaViewQuestionDto> kbaAuthQues = authDao.getKbaQuesForAuth(pageRowstart, numRowFromStart, userId);
		List<KbaViewQuestionDto> kbaViewQues = new ArrayList<>();
		Iterator it = kbaAuthQues.iterator();

		while (it.hasNext()) {
			Object[] result = (Object[]) it.next(); // Iterating through array object
			kbaViewQues.add(new KbaViewQuestionDto(result[0], result[1]));
		}
		return kbaViewQues;
	}

	@Override
	public String getTotalCountQuesShow() {
		
		String totalQuesToShow = authDao.getTotalCountQuesShow();
		return totalQuesToShow;
	}
}
