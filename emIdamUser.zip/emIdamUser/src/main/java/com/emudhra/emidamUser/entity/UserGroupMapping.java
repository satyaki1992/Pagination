package com.emudhra.emidamUser.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserGroupMapping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8661294757931819195L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int	 user_group_id;

	@Column
	private int	user_id;

	@Column
	private Date user_group_created_date;

	@Column
	private Date user_group_modified_date;

	@Column
	private String	user_group_created_user;

	@Column
	private String	user_group_modified_user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "usergroupmapping", nullable = false)
	private UserMaster usergroupmapping;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userGroupsUserGroupMapping", nullable = false)
	private UserGroups userGroupsUserGroupMapping;
	
	public UserGroups getUserGroupsUserGroupMapping() {
		return userGroupsUserGroupMapping;
	}

	public void setUserGroupsUserGroupMapping(UserGroups userGroupsUserGroupMapping) {
		this.userGroupsUserGroupMapping = userGroupsUserGroupMapping;
	}

	public UserMaster getUsergroupmapping() {
		return usergroupmapping;
	}

	public void setUsergroupmapping(UserMaster usergroupmapping) {
		this.usergroupmapping = usergroupmapping;
	}

	public int getUser_group_id() {
		return user_group_id;
	}

	public void setUser_group_id(int user_group_id) {
		this.user_group_id = user_group_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public Date getUser_group_created_date() {
		return user_group_created_date;
	}

	public void setUser_group_created_date(Date user_group_created_date) {
		this.user_group_created_date = user_group_created_date;
	}

	public Date getUser_group_modified_date() {
		return user_group_modified_date;
	}

	public void setUser_group_modified_date(Date user_group_modified_date) {
		this.user_group_modified_date = user_group_modified_date;
	}

	public String getUser_group_created_user() {
		return user_group_created_user;
	}

	public void setUser_group_created_user(String user_group_created_user) {
		this.user_group_created_user = user_group_created_user;
	}

	public String getUser_group_modified_user() {
		return user_group_modified_user;
	}

	public void setUser_group_modified_user(String user_group_modified_user) {
		this.user_group_modified_user = user_group_modified_user;
	}



}
