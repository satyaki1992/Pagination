package com.emudhra.emidamUser.daoImpl;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.emudhra.emidamUser.constants.IdamUserConstants;
import com.emudhra.emidamUser.dao.SMSOTPAuthDao;
import com.emudhra.emidamUser.entity.UserMaster;
import com.emudhra.emidamUser.util.OTPUtility;

@Repository
@Transactional
public class SMSOTPAuthDaoImpl implements SMSOTPAuthDao {
	@Autowired
	OTPUtility utility;

	@Autowired
	EntityManager entityManager;

	@Override
	public void sendMobileOTP(String custID, String mobileNo) {
		try {
			String otpGenerated = utility.generateTOTP(custID.getBytes(), "6", "HmacSHA1");
			utility.sendSMS("http://103.247.98.91/API/SendMsg.aspx?",
					"uname=20141463&pass=emudhratest&send=eMuTst&dest=" + mobileNo + "&msg=" + otpGenerated);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean authenticate(String custID, String verificationCode) {
		String otpGenerated = utility.generateTOTP(custID.getBytes(), "6", "HmacSHA1");
		if (verificationCode.equals(otpGenerated))
			return true;
		else
			return false;
	}

	@Override
	public String findMobileNumber(String id) {
		final String GET_MOB_NO = "SELECT user_mobile_number FROM UserMaster WHERE user_id = :userId";
		String mobNo = (String) entityManager.createQuery(GET_MOB_NO).setParameter("userId", Integer.valueOf(id))
				.getSingleResult();
		if (mobNo.equals("") || mobNo.isEmpty() || mobNo.length() != 10)
			return IdamUserConstants.MOBNO_NOT_REG;
		else
			return mobNo;
	}

	@Override
	public void saveMobileNumber(int userId, String mobNo) {
		UserMaster user = (UserMaster) entityManager.createQuery("FROM UserMaster WHERE user_id = :userID")
				.setParameter("userID", userId).getSingleResult();
		user.setUser_mobile_number(mobNo);
	}

	@Override
	public String sendEmailOTP(int userId) {
		final String GET_USER_EMAIL = "SELECT user_email_id FROM UserMaster WHERE user_id = :userId";
		String email = (String) entityManager.createQuery(GET_USER_EMAIL).setParameter("userId", userId).getSingleResult();
		String otpGenerated = utility.generateTOTP(String.valueOf(userId).getBytes(), "6", "HmacSHA1");
		utility.emailOtp(email, otpGenerated);
		return email;
	}

}
