function checkValidation() {
	
	
}