var questions = new Array();
var answers = new Array();	
function checkValidation(regQues, numeric, specialCharacters, charLimit,
		maxCharsAns, minCharsAns, SameAnsMultiQues, noQuesWordInAns)
{
	var step;
	for (step = 1; step <= regQues; step++) {
		var nameField = 'question'+step;
		window['question'] = document.getElementById(nameField).value;
		var ques = eval('question'); 
		questions[step-1] = ques;
		//alert(' ques ' + ques);
		var ansField = 'answer'+step;
		window['answer'] = document.getElementById(ansField).value;
		var ans = eval('answer');
		answers[step-1] = ans;
		//alert(' ans ' + ans);
		
	}
	for (step = 0; step < regQues; step++) {
		if(questions[step]=='Select a question')
		{
			alert('Please select question ' + (step+1));
			return false;
		}	
	}
	for (step = 0; step < regQues; step++) {
		if(answers[step]=='')
		{
			alert('Please select answer ' + (step+1));
			return false;
		}
	}
	callAjax();
	//event.preventDefault();
}