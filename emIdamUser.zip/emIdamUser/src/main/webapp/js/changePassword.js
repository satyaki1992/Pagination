function checkValidation(passwordLenMin, passwordLenMax, numericLenMin,
			numericLenMax,upperCaseLenMin, upperCaseLenMax, lowerCaseLenMin, lowerCaseLenMax) {
    	
    	var newPassword  = document.getElementById("newPassword").value;
    	var confirmPassword  = document.getElementById("confirmPassword").value;
    	if(newPassword == '')
    	{
    		alert('Please enter New password');
    		event.preventDefault();
    		return false;
    	}
    	if(confirmPassword=='')
    	{
    		alert('Please enter Confirm password');
    		event.preventDefault();
    		return false;
    	}
    	if(newPassword != confirmPassword)
    	{
    		alert('New and confirm password does not match');
    		event.preventDefault();
    		return false;
    	}
    	if(newPassword.length<passwordLenMin || newPassword.length>passwordLenMax)
    	{
    		alert('Password Length should be between ' + passwordLenMin + ' to ' + passwordLenMax + ' characters');
    		event.preventDefault();
    		return false;
    	}
    	findCountNumericCase(newPassword, numericLenMin, numericLenMax);
    	findCountUpperCase(newPassword, upperCaseLenMin, upperCaseLenMax);
    	findCountLowerCase(newPassword, lowerCaseLenMin, lowerCaseLenMax);
}
function findCountNumericCase(newPassword, numericLenMin, numericLenMax) {
	
	var step,totNumericChar=0;
	for(step=0; step<newPassword.length; step++)
	{
		if(newPassword.charAt(step)>=0 && newPassword.charAt(step)<=9)
			totNumericChar++;
	}
	if(totNumericChar<numericLenMin || totNumericChar>numericLenMax)
	{
		alert('Password should have minimum of ' + numericLenMin + ' numeric characters and maximum of' + numericLenMax
				+ ' numeric characters');
		event.preventDefault();
		return false;
	}
}
function findCountUpperCase(newPassword, upperCaseLenMin, upperCaseLenMax) {
	
	var step,totUppCaseChar=0;
	for(step=0; step<newPassword.length; step++)
	{
		if(newPassword.charAt(step)>='A' && newPassword.charAt(step)<='Z')
			totUppCaseChar++;
	}
	if(totUppCaseChar<upperCaseLenMin || totUppCaseChar>upperCaseLenMax)
	{
		alert('Password should have minimum of ' + upperCaseLenMin + ' upperCase characters and maximum of' + upperCaseLenMax
				+ ' upperCase characters');
		event.preventDefault();
		return false;
	}
		
}
function findCountLowerCase(newPassword, lowerCaseLenMin, lowerCaseLenMax) {
	
	var step,totLowerCaseChar=0;
	for(step=0; step<newPassword.length; step++)
	{
		if(newPassword.charAt(step)>='a' && newPassword.charAt(step)<='z')
			totUppCaseChar++;
	}
	if(totLowerCaseChar<lowerCaseLenMin || totLowerCaseChar>lowerCaseLenMax)
	{
		alert('Password should have minimum of ' + lowerCaseLenMin + ' lowerCase characters and maximum of' + lowerCaseLenMax
				+ ' lowerCase characters');
		event.preventDefault();
		return false;
	}
		
}